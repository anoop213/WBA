package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.Config;
import com.dxc.PdfGeneratorMicroservice.models.PollResult;
import org.junit.Test;

import java.util.UUID;

import static org.junit.Assert.assertEquals;

public class PollingServiceTests {
    private String sharedDirectory = "src/test/files/services/pollingService/sharedDirectory";

    @Test
    public void testPollJobNeitherReceived() {
        // Arrange
        String neitherReceivedCupsUuid = UUID.randomUUID().toString();
        PollResult expectedPollResult = PollResult.Undefined;
        Config config = new Config();
        config.sharedDirectory = sharedDirectory;
        FileReaderService frService = new FileReaderService();
        PollingService service = PollingService.getInstance(config, frService);

        //Act
        PollResult actualPollResult = service.poll(neitherReceivedCupsUuid);

        // Assert
        assertEquals("The poll enum should be correct",
                expectedPollResult, actualPollResult);
    }

    @Test
    public void testPollJobCompleted() {
        // Arrange
        String completedCupsUuid = UUID.randomUUID().toString();
        PollResult expectedPollResult = PollResult.Completed;
        Config config = new Config();
        config.sharedDirectory = sharedDirectory;
        FileReaderService frService = new FileReaderService();
        PollingService service = PollingService.getInstance(config, frService);
        service.setComplete(completedCupsUuid);

        //Act
        PollResult actualPollResult = service.poll(completedCupsUuid);

        // Assert
        assertEquals("The poll enum should be correct",
                expectedPollResult, actualPollResult);
    }

    @Test
    public void testPollJobInProgress() {
        // Arrange
        String inProgressCupsUuid = "1590fbab-d996-4831-a8f3-67d791f027b4";
        PollResult expectedPollResult = PollResult.InProgress;
        Config config = new Config();
        config.sharedDirectory = sharedDirectory;
        FileReaderService frService = new FileReaderService();
        PollingService service = PollingService.getInstance(config, frService);

        //Act
        PollResult actualPollResult = service.poll(inProgressCupsUuid);

        // Assert
        assertEquals("The poll enum should be correct",
                expectedPollResult, actualPollResult);
    }

    @Test
    public void testPollJobFailed() {
        // Arrange
        String failedCupsUuid =  UUID.randomUUID().toString();
        String errorMessage = "Error";
        PollResult expectedPollResult = PollResult.Failed;
        Config config = new Config();
        config.sharedDirectory = sharedDirectory;
        FileReaderService frService = new FileReaderService();
        PollingService service = PollingService.getInstance(config, frService);
        ErrorService errorService = ErrorService.getInstance();
        errorService.putMessage(failedCupsUuid, errorMessage);

        //Act
        PollResult actualPollResult = service.poll(failedCupsUuid);

        // Assert
        assertEquals("The poll enum should be correct",
                expectedPollResult, actualPollResult);
    }
}
