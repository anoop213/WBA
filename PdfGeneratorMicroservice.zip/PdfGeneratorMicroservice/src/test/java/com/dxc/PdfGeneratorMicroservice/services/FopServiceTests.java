package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.Config;
import com.dxc.PdfGeneratorMicroservice.exceptions.*;
import com.dxc.PdfGeneratorMicroservice.models.PdsPage;
import org.junit.Test;
import org.w3c.dom.Document;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class FopServiceTests {
    private String sampleXmlFilePath = "src/test/files/services/fopService/sampleXml.xml";
    private String sampleXslFilePath = "src/test/files/services/fopService/sampleXsl.xsl";
    private String outputPdfHappyPath = "src/test/files/services/fopService/happyPath.pdf";
    private String nonExistentFilePath = "src/test/files/services/fopService/doesNotExist.txt";
    private String outputPdfXmlNonExistent = "src/test/files/services/fopService/unhappyPath1.pdf";
    private String outputPdfXslNonExistent = "src/test/files/services/fopService/invalidXsl.pdf";
    private String illegalOutputPdfPath = "src/test/files/services/fopService/illegal***.txt";
    private String junkInputFile = "src/test/files/services/fopService/junkFile.txt";
    private String outputPdfXmlJunk = "src/test/files/services/fopService/junkXml.pdf";
    private String outputPdfXslJunk = "src/test/files/services/fopService/junkXsl.pdf";

    // Case: DONE Missing input files (2 Cases)
    // Case: DONE Illegal output filename (1 Case)
    // Case: DONE Junk input files (2 Cases)

    @Test
    public void testGeneratePdfForSpecifiedFilesHappyPath() throws IOException {
        // Arrange
        String xmlFilename = sampleXmlFilePath;
        String xsltFilename = sampleXslFilePath;
        String pdfFilename = outputPdfHappyPath;
        boolean expectedGeneratedFile = true;
        Config config = new Config();
        config.tempDirectory = "C://temp";
        FopService service = new FopService(config);
        FileReaderService frService = new FileReaderService();
        FileWriterService fwService = new FileWriterService();
        fwService.deleteFile(pdfFilename);

        // Act
        service.generatePdfForSpecifiedFiles(xmlFilename, xsltFilename, pdfFilename);
        List<String> resultingLines = frService.readFile(pdfFilename);
        long generatedFileSize = Files.size(Paths.get(pdfFilename));
        boolean actualGeneratedFile = generatedFileSize > 1000l;

        // Assert
        assertEquals("A Pdf file should have been generated", expectedGeneratedFile, actualGeneratedFile);
    }

    @Test
    public void testGeneratePdfForSpecifiedFilesMissingXmlFile() throws IOException {
        // Arrange
        String xmlFilename = nonExistentFilePath;
        String xsltFilename = sampleXslFilePath;
        String pdfFilename = outputPdfXmlNonExistent;
        boolean expectedExceptionThrown = true;
        boolean actualExceptionThrown = false;
        Config config = new Config();
        config.tempDirectory = "C://temp";
        FopService service = new FopService(config);
        FileWriterService fwService = new FileWriterService();
        fwService.deleteFile(pdfFilename);

        // Act
        try {
            service.generatePdfForSpecifiedFiles(xmlFilename, xsltFilename, pdfFilename);
            fail("An exception should have been thrown");
        } catch(NoXmlDataException e) {
            actualExceptionThrown = true;
        }

        // Assert
        assertEquals("A exception should have been thrown", expectedExceptionThrown, actualExceptionThrown);
    }

    @Test
    public void testGeneratePdfForSpecifiedFilesMissingXslFile() throws IOException {
        // Arrange
        String xmlFilename = sampleXmlFilePath;
        String xsltFilename = nonExistentFilePath;
        String pdfFilename = outputPdfXslNonExistent;
        boolean expectedExceptionThrown = true;
        boolean actualExceptionThrown = false;
        Config config = new Config();
        config.tempDirectory = "C://temp";
        FopService service = new FopService(config);
        FileWriterService fwService = new FileWriterService();
        fwService.deleteFile(pdfFilename);

        // Act
        try {
            service.generatePdfForSpecifiedFiles(xmlFilename, xsltFilename, pdfFilename);
            fail("An exception should have been thrown");
        } catch(NoXslTransformationException e) {
            actualExceptionThrown = true;
        }

        // Assert
        assertEquals("A exception should have been thrown", expectedExceptionThrown, actualExceptionThrown);
    }

    @Test
    public void testGeneratePdfForSpecifiedFilesIllegalOutputFilePath() throws IOException {
        // Arrange
        String xmlFilename = sampleXmlFilePath;
        String xsltFilename = sampleXslFilePath;
        String pdfFilename = illegalOutputPdfPath;
        boolean expectedExceptionThrown = true;
        boolean actualExceptionThrown = false;
        Config config = new Config();
        config.tempDirectory = "C://temp";
        FopService service = new FopService(config);
        FileWriterService fwService = new FileWriterService();
        fwService.deleteFile(pdfFilename);

        // Act
        try {
            service.generatePdfForSpecifiedFiles(xmlFilename, xsltFilename, pdfFilename);
            fail("An exception should have been thrown");
        } catch(IllegalPdfFileNameException e) {
            actualExceptionThrown = true;
        }

        // Assert
        assertEquals("A exception should have been thrown", expectedExceptionThrown, actualExceptionThrown);
    }

    // TODO: Move this
    public void utilityGenerateXml() {
        XmlTransformerService xtService = new XmlTransformerService();
        PdsExtractorService peService = new PdsExtractorService();
        FileReaderService frService = new FileReaderService();
        FileWriterService fwService = new FileWriterService();

        List<String> lines = frService.readFile("src/test/files/services/fopService/TwoForms.txt");
        List<PdsPage> pdsPages = peService.Extract(lines);
        Document xmlDocument = xtService.generateXML(pdsPages);
        fwService.writeFile(xmlDocument, "src/test/files/services/fopService/generatedXml.xml");
    }

    @Test
    public void testGeneratePdfForSpecifiedFilesJunkXmlFile() throws IOException {
        // Arrange
        String xmlFilename = junkInputFile;
        String xsltFilename = sampleXslFilePath;
        String pdfFilename = outputPdfXmlJunk;
        boolean expectedExceptionThrown = true;
        boolean actualExceptionThrown = false;
        Config config = new Config();
        config.tempDirectory = "C://temp";
        FopService service = new FopService(config);
        FileWriterService fwService = new FileWriterService();
        fwService.deleteFile(pdfFilename);

        // Act
        try {
            service.generatePdfForSpecifiedFiles(xmlFilename, xsltFilename, pdfFilename);
            fail("An exception should have been thrown");
        } catch(FailureToReadXmlFile e) {
            actualExceptionThrown = true;
        }

        // Assert
        assertEquals("A exception should have been thrown", expectedExceptionThrown, actualExceptionThrown);
    }

    @Test
    public void testGeneratePdfForSpecifiedFilesJunkXslFile() throws IOException {
        // Arrange
        String xmlFilename = sampleXmlFilePath;
        String xsltFilename = junkInputFile;
        String pdfFilename = outputPdfXslJunk;
        boolean expectedExceptionThrown = true;
        boolean actualExceptionThrown = false;
        Config config = new Config();
        config.tempDirectory = "C://temp";
        FopService service = new FopService(config);
        FileWriterService fwService = new FileWriterService();
        fwService.deleteFile(pdfFilename);

        // Act
        try {
            service.generatePdfForSpecifiedFiles(xmlFilename, xsltFilename, pdfFilename);
            fail("An exception should have been thrown");
        } catch(FailureToReadXslFile e) {
            actualExceptionThrown = true;
        }

        // Assert
        assertEquals("A exception should have been thrown", expectedExceptionThrown, actualExceptionThrown);
    }
}
