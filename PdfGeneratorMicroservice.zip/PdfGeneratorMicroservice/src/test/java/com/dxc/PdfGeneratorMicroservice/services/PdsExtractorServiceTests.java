package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.exceptions.PdsExtractionFailedException;
import com.dxc.PdfGeneratorMicroservice.models.PdsPage;
import com.dxc.PdfGeneratorMicroservice.models.PdsParam;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class PdsExtractorServiceTests {
    private String textFileFilePath = "src/test/files/services/pdsExtractorService/Text.txt";
    private String twoFormsFileFilePath = "src/test/files/services/pdsExtractorService/TwoForms.txt";
    private String fourFormsFileFilePath = "src/test/files/services/pdsExtractorService/FourForms.txt";
    private String pglFromScottFilePath = "src/test/files/services/pdsExtractorService/pglFromScott.bom";
    private String emptyPglFilePath = "src/test/files/services/pdsExtractorService/EmptyFile.txt";
    private String nonsensePglFilePath = "src/test/files/services/pdsExtractorService/NonsenseFile.txt";

    @Test
    public void testPdsExtractorServiceTwoFormsFile() {
        // Arrange
        int expectedNumberOfPdsPages = 2;
        FileReaderService frService = new FileReaderService();
        List<String> lines = frService.readFile(twoFormsFileFilePath);

        //Act
        PdsExtractorService service = new PdsExtractorService();
        List<PdsPage> pages = service.Extract(lines);

        //Assert
        assertEquals("There should be 2 pds pages present", expectedNumberOfPdsPages, pages.size());
    }

    @Test
    public void testPdsExtractorServiceFourFormsFile() {
        // Arrange
        int expectedNumberOfPdsPages = 4;
        FileReaderService frService = new FileReaderService();
        List<String> lines = frService.readFile(fourFormsFileFilePath);

        //Act
        PdsExtractorService service = new PdsExtractorService();
        List<PdsPage> pages = service.Extract(lines);

        //Assert
        assertEquals("There should be 4 pds pages present", expectedNumberOfPdsPages, pages.size());
    }

    @Test
    public void testPdsExtractorServiceTwoFormsFileFormTypes() {
        // Arrange
        String expectedForm1Type = "OUTHED";
        String expectedForm2Type = "TWNTRY";
        FileReaderService frService = new FileReaderService();
        List<String> lines = frService.readFile(twoFormsFileFilePath);

        //Act
        PdsExtractorService service = new PdsExtractorService();
        List<PdsPage> pages = service.Extract(lines);
        String actualForm1Type = pages.get(0).getFormType();
        String actualForm2Type = pages.get(1).getFormType();

        //Assert
        assertEquals("The first form should have the correct type", expectedForm1Type, actualForm1Type);
        assertEquals("The second form should have the correct type", expectedForm2Type, actualForm2Type);
    }

    @Test
    public void testPdsExtractorServiceFourFormsFileFormTypes() {
        // Arrange
        String expectedForm1Type = "OUTHED";
        String expectedForm2Type = "TWNTRY";
        String expectedForm3Type = "TWNTRY";
        String expectedForm4Type = "TWNTRY";
        FileReaderService frService = new FileReaderService();
        List<String> lines = frService.readFile(fourFormsFileFilePath);

        //Act
        PdsExtractorService service = new PdsExtractorService();
        List<PdsPage> pages = service.Extract(lines);
        String actualForm1Type = pages.get(0).getFormType();
        String actualForm2Type = pages.get(1).getFormType();
        String actualForm3Type = pages.get(2).getFormType();
        String actualForm4Type = pages.get(3).getFormType();

        //Assert
        assertEquals("The first form should have the correct type", expectedForm1Type, actualForm1Type);
        assertEquals("The second form should have the correct type", expectedForm2Type, actualForm2Type);
        assertEquals("The third form should have the correct type", expectedForm3Type, actualForm3Type);
        assertEquals("The fourth form should have the correct type", expectedForm4Type, actualForm4Type);
    }

    @Test
    public void testPdsExtractorServiceTwoFormsFileParamCount() {
        // Arrange
        int expectedForm1ParamsCount = 4;
        int expectedForm2ParamsCount = 35;
        FileReaderService frService = new FileReaderService();
        List<String> lines = frService.readFile(twoFormsFileFilePath);

        //Act
        PdsExtractorService service = new PdsExtractorService();
        List<PdsPage> pages = service.Extract(lines);
        int actualForm1ParamsCount = pages.get(0).getParamsCount();
        int actualForm2ParamsCount = pages.get(1).getParamsCount();

        //Assert
        assertEquals("The first form should have the correct no of params",
                expectedForm1ParamsCount, actualForm1ParamsCount);
        assertEquals("The second form should have the correct no of params",
                expectedForm2ParamsCount, actualForm2ParamsCount);
    }

    @Test
    public void testPdsExtractorServiceFourFormsFileParamCount() {
        // Arrange
        int expectedForm1ParamsCount = 4;
        int expectedForm2ParamsCount = 35;
        int expectedForm3ParamsCount = 35;
        int expectedForm4ParamsCount = 35;
        FileReaderService frService = new FileReaderService();
        List<String> lines = frService.readFile(fourFormsFileFilePath);

        //Act
        PdsExtractorService service = new PdsExtractorService();
        List<PdsPage> pages = service.Extract(lines);
        int actualForm1ParamsCount = pages.get(0).getParamsCount();
        int actualForm2ParamsCount = pages.get(1).getParamsCount();
        int actualForm3ParamsCount = pages.get(2).getParamsCount();
        int actualForm4ParamsCount = pages.get(3).getParamsCount();

        //Assert
        assertEquals("The first form should have the correct no of params",
                expectedForm1ParamsCount, actualForm1ParamsCount);
        assertEquals("The second form should have the correct no of params",
                expectedForm2ParamsCount, actualForm2ParamsCount);
        assertEquals("The third form should have the correct no of params",
                expectedForm3ParamsCount, actualForm3ParamsCount);
        assertEquals("The fourth form should have the correct no of params",
                expectedForm4ParamsCount, actualForm4ParamsCount);
    }

    @Test
    public void testPdsExtractorServiceTwoFormsFilePage1ParamValues() {
        // Arrange
        //¬AF03;¦200¦
        //¬AF04;¦HEADER LABEL        ¦
        //¬AF05;¦B.COM¦
        //¬AF12;¦26/04/21¦
        String expectedPage1Param1ParamName = "AF03";
        String expectedPage1Param1ParamValue = "200";
        String expectedPage1Param2ParamName = "AF04";
        String expectedPage1Param2ParamValue = "HEADER LABEL        ";
        String expectedPage1Param3ParamName = "AF05";
        String expectedPage1Param3ParamValue = "B.COM";
        String expectedPage1Param4ParamName = "AF12";
        String expectedPage1Param4ParamValue = "26/04/21";
        FileReaderService frService = new FileReaderService();
        List<String> lines = frService.readFile(twoFormsFileFilePath);

        //Act
        PdsExtractorService service = new PdsExtractorService();
        List<PdsPage> pages = service.Extract(lines);
        PdsPage page1 = pages.get(0);
        List<PdsParam> page1Params = page1.getParams();
        String actualPage1Param1ParamName = page1Params.get(0).getName();
        String actualPage1Param1ParamValue = page1Params.get(0).getValue();
        String actualPage1Param2ParamName = page1Params.get(1).getName();
        String actualPage1Param2ParamValue = page1Params.get(1).getValue();
        String actualPage1Param3ParamName = page1Params.get(2).getName();
        String actualPage1Param3ParamValue = page1Params.get(2).getValue();
        String actualPage1Param4ParamName = page1Params.get(3).getName();
        String actualPage1Param4ParamValue = page1Params.get(3).getValue();

        //Assert
        assertEquals("The first param on the first page should have the correct name",
                expectedPage1Param1ParamName, actualPage1Param1ParamName);
        assertEquals("The first param on the first page should have the correct value",
                expectedPage1Param1ParamValue, actualPage1Param1ParamValue);
        assertEquals("The second param on the first page should have the correct name",
                expectedPage1Param2ParamName, actualPage1Param2ParamName);
        assertEquals("The second param on the first page should have the correct value",
                expectedPage1Param2ParamValue, actualPage1Param2ParamValue);
        assertEquals("The third param on the first page should have the correct name",
                expectedPage1Param3ParamName, actualPage1Param3ParamName);
        assertEquals("The third param on the first page should have the correct value",
                expectedPage1Param3ParamValue, actualPage1Param3ParamValue);
        assertEquals("The fourth param on the first page should have the correct name",
                expectedPage1Param4ParamName, actualPage1Param4ParamName);
        assertEquals("The fourth param on the first page should have the correct value",
                expectedPage1Param4ParamValue, actualPage1Param4ParamValue);
    }

    @Test
    public void testPdsExtractorServiceTwoFormsFilePage2ParamValues() {
        String expectedPage1Param1ParamName = "AF02";
        String expectedPage1Param1ParamValue = "BURT";
        String expectedPage1Param2ParamName = "AF03";
        String expectedPage1Param2ParamValue = "14499081";
        String expectedPage1Param3ParamName = "AF04";
        String expectedPage1Param3ParamValue = "26/04/21";
        String expectedPage1Param4ParamName = "AF05";
        String expectedPage1Param4ParamValue = "4910 ";
        String expectedPage1Param5ParamName = "AF06";
        String expectedPage1Param5ParamValue = "B.COM";
        String expectedPage1Param6ParamName = "AF07";
        String expectedPage1Param6ParamValue = "   ";
        String expectedPage1Param7ParamName = "BF08";
        String expectedPage1Param7ParamValue = "05014910024379";
        String expectedPage1Param8ParamName = "AF09";
        String expectedPage1Param8ParamValue = "05014910024379";
        String expectedPage1Param9ParamName = "AF10";
        String expectedPage1Param9ParamValue = "0001";
        String expectedPage1Param10ParamName = "AF11";
        String expectedPage1Param10ParamValue = "IMMEDIATE SUPPLY    ";
        String expectedPage1Param11ParamName = "AF12";
        String expectedPage1Param11ParamValue = " ";
        String expectedPage1Param12ParamName = "AF13";
        String expectedPage1Param12ParamValue = "                         ";
        String expectedPage1Param13ParamName = "AF14";
        String expectedPage1Param13ParamValue = "REPLN";
        String expectedPage1Param14ParamName = "AF15";
        String expectedPage1Param14ParamValue = "        ";
        String expectedPage1Param15ParamName = "AF16";
        String expectedPage1Param15ParamValue = "        ";
        String expectedPage1Param16ParamName = "AF17";
        String expectedPage1Param16ParamValue = "        ";
        String expectedPage1Param17ParamName = "AF18";
        String expectedPage1Param17ParamValue = "        ";
        String expectedPage1Param18ParamName = "AF19";
        String expectedPage1Param18ParamValue = "        ";
        String expectedPage1Param19ParamName = "AF20";
        String expectedPage1Param19ParamValue = "        ";
        String expectedPage1Param20ParamName = "AF21";
        String expectedPage1Param20ParamValue = "        ";
        String expectedPage1Param21ParamName = "AF22";
        String expectedPage1Param21ParamValue = "        ";
        String expectedPage1Param22ParamName = "AF23";
        String expectedPage1Param22ParamValue = "        ";
        String expectedPage1Param23ParamName = "AF24";
        String expectedPage1Param23ParamValue = "        ";
        String expectedPage1Param24ParamName = "AF25";
        String expectedPage1Param24ParamValue = "        ";
        String expectedPage1Param25ParamName = "AF26";
        String expectedPage1Param25ParamValue = "        ";
        String expectedPage1Param26ParamName = "AF27";
        String expectedPage1Param26ParamValue = "    ";
        String expectedPage1Param27ParamName = "AF28";
        String expectedPage1Param27ParamValue = "                              ";
        String expectedPage1Param28ParamName = "AF29";
        String expectedPage1Param28ParamValue = "                              ";
        String expectedPage1Param29ParamName = "AF30";
        String expectedPage1Param29ParamValue = "                              ";
        String expectedPage1Param30ParamName = "AF31";
        String expectedPage1Param30ParamValue = "                              ";
        String expectedPage1Param31ParamName = "AF32";
        String expectedPage1Param31ParamValue = "                              ";
        String expectedPage1Param32ParamName = "BF33";
        String expectedPage1Param32ParamValue = "14499081";
        String expectedPage1Param33ParamName = "AF35";
        String expectedPage1Param33ParamValue = " 538";
        String expectedPage1Param34ParamName = "AF36";
        String expectedPage1Param34ParamValue = "GIFT";
        String expectedPage1Param35ParamName = "AF37";
        String expectedPage1Param35ParamValue = "-----";
        FileReaderService frService = new FileReaderService();
        List<String> lines = frService.readFile(twoFormsFileFilePath);

        //Act
        PdsExtractorService service = new PdsExtractorService();
        List<PdsPage> pages = service.Extract(lines);
        PdsPage page2 = pages.get(1);
        List<PdsParam> page2Params = page2.getParams();
        String actualPage1Param1ParamName = page2Params.get(0).getName();
        String actualPage1Param1ParamValue = page2Params.get(0).getValue();
        String actualPage1Param2ParamName = page2Params.get(1).getName();
        String actualPage1Param2ParamValue = page2Params.get(1).getValue();
        String actualPage1Param3ParamName = page2Params.get(2).getName();
        String actualPage1Param3ParamValue = page2Params.get(2).getValue();
        String actualPage1Param4ParamName = page2Params.get(3).getName();
        String actualPage1Param4ParamValue = page2Params.get(3).getValue();
        String actualPage1Param5ParamName = page2Params.get(4).getName();
        String actualPage1Param5ParamValue = page2Params.get(4).getValue();
        String actualPage1Param6ParamName = page2Params.get(5).getName();
        String actualPage1Param6ParamValue = page2Params.get(5).getValue();
        String actualPage1Param7ParamName = page2Params.get(6).getName();
        String actualPage1Param7ParamValue = page2Params.get(6).getValue();
        String actualPage1Param8ParamName = page2Params.get(7).getName();
        String actualPage1Param8ParamValue = page2Params.get(7).getValue();
        String actualPage1Param9ParamName = page2Params.get(8).getName();
        String actualPage1Param9ParamValue = page2Params.get(8).getValue();
        String actualPage1Param10ParamName = page2Params.get(9).getName();
        String actualPage1Param10ParamValue = page2Params.get(9).getValue();
        String actualPage1Param11ParamName = page2Params.get(10).getName();
        String actualPage1Param11ParamValue = page2Params.get(10).getValue();
        String actualPage1Param12ParamName = page2Params.get(11).getName();
        String actualPage1Param12ParamValue = page2Params.get(11).getValue();
        String actualPage1Param13ParamName = page2Params.get(12).getName();
        String actualPage1Param13ParamValue = page2Params.get(12).getValue();
        String actualPage1Param14ParamName = page2Params.get(13).getName();
        String actualPage1Param14ParamValue = page2Params.get(13).getValue();
        String actualPage1Param15ParamName = page2Params.get(14).getName();
        String actualPage1Param15ParamValue = page2Params.get(14).getValue();
        String actualPage1Param16ParamName = page2Params.get(15).getName();
        String actualPage1Param16ParamValue = page2Params.get(15).getValue();
        String actualPage1Param17ParamName = page2Params.get(16).getName();
        String actualPage1Param17ParamValue = page2Params.get(16).getValue();
        String actualPage1Param18ParamName = page2Params.get(17).getName();
        String actualPage1Param18ParamValue = page2Params.get(17).getValue();
        String actualPage1Param19ParamName = page2Params.get(18).getName();
        String actualPage1Param19ParamValue = page2Params.get(18).getValue();
        String actualPage1Param20ParamName = page2Params.get(19).getName();
        String actualPage1Param20ParamValue = page2Params.get(19).getValue();
        String actualPage1Param21ParamName = page2Params.get(20).getName();
        String actualPage1Param21ParamValue = page2Params.get(20).getValue();
        String actualPage1Param22ParamName = page2Params.get(21).getName();
        String actualPage1Param22ParamValue = page2Params.get(21).getValue();
        String actualPage1Param23ParamName = page2Params.get(22).getName();
        String actualPage1Param23ParamValue = page2Params.get(22).getValue();
        String actualPage1Param24ParamName = page2Params.get(23).getName();
        String actualPage1Param24ParamValue = page2Params.get(23).getValue();
        String actualPage1Param25ParamName = page2Params.get(24).getName();
        String actualPage1Param25ParamValue = page2Params.get(24).getValue();
        String actualPage1Param26ParamName = page2Params.get(25).getName();
        String actualPage1Param26ParamValue = page2Params.get(25).getValue();
        String actualPage1Param27ParamName = page2Params.get(26).getName();
        String actualPage1Param27ParamValue = page2Params.get(26).getValue();
        String actualPage1Param28ParamName = page2Params.get(27).getName();
        String actualPage1Param28ParamValue = page2Params.get(27).getValue();
        String actualPage1Param29ParamName = page2Params.get(28).getName();
        String actualPage1Param29ParamValue = page2Params.get(28).getValue();
        String actualPage1Param30ParamName = page2Params.get(29).getName();
        String actualPage1Param30ParamValue = page2Params.get(29).getValue();
        String actualPage1Param31ParamName = page2Params.get(30).getName();
        String actualPage1Param31ParamValue = page2Params.get(30).getValue();
        String actualPage1Param32ParamName = page2Params.get(31).getName();
        String actualPage1Param32ParamValue = page2Params.get(31).getValue();
        String actualPage1Param33ParamName = page2Params.get(32).getName();
        String actualPage1Param33ParamValue = page2Params.get(32).getValue();
        String actualPage1Param34ParamName = page2Params.get(33).getName();
        String actualPage1Param34ParamValue = page2Params.get(33).getValue();
        String actualPage1Param35ParamName = page2Params.get(34).getName();
        String actualPage1Param35ParamValue = page2Params.get(34).getValue();

        //Assert
        assertEquals("Param 1 on the second page should have the correct name",
                expectedPage1Param1ParamName, actualPage1Param1ParamName);
        assertEquals("Param 1 on the second page should have the correct value",
                expectedPage1Param1ParamValue, actualPage1Param1ParamValue);
        assertEquals("Param 2 on the second page should have the correct name",
                expectedPage1Param2ParamName, actualPage1Param2ParamName);
        assertEquals("Param 2 on the second page should have the correct value",
                expectedPage1Param2ParamValue, actualPage1Param2ParamValue);
        assertEquals("Param 3 on the second page should have the correct name",
                expectedPage1Param3ParamName, actualPage1Param3ParamName);
        assertEquals("Param 3 on the second page should have the correct value",
                expectedPage1Param3ParamValue, actualPage1Param3ParamValue);
        assertEquals("Param 4 on the second page should have the correct name",
                expectedPage1Param4ParamName, actualPage1Param4ParamName);
        assertEquals("Param 4 on the second page should have the correct value",
                expectedPage1Param4ParamValue, actualPage1Param4ParamValue);
        assertEquals("Param 5 on the second page should have the correct name",
                expectedPage1Param5ParamName, actualPage1Param5ParamName);
        assertEquals("Param 5 on the second page should have the correct value",
                expectedPage1Param5ParamValue, actualPage1Param5ParamValue);
        assertEquals("Param 6 on the second page should have the correct name",
                expectedPage1Param6ParamName, actualPage1Param6ParamName);
        assertEquals("Param 6 on the second page should have the correct value",
                expectedPage1Param6ParamValue, actualPage1Param6ParamValue);
        assertEquals("Param 7 on the second page should have the correct name",
                expectedPage1Param7ParamName, actualPage1Param7ParamName);
        assertEquals("Param 7 on the second page should have the correct value",
                expectedPage1Param7ParamValue, actualPage1Param7ParamValue);
        assertEquals("Param 8 on the second page should have the correct name",
                expectedPage1Param8ParamName, actualPage1Param8ParamName);
        assertEquals("Param 8 on the second page should have the correct value",
                expectedPage1Param8ParamValue, actualPage1Param8ParamValue);
        assertEquals("Param 9 on the second page should have the correct name",
                expectedPage1Param9ParamName, actualPage1Param9ParamName);
        assertEquals("Param 9 on the second page should have the correct value",
                expectedPage1Param9ParamValue, actualPage1Param9ParamValue);
        assertEquals("Param 10 on the second page should have the correct name",
                expectedPage1Param10ParamName, actualPage1Param10ParamName);
        assertEquals("Param 10 on the second page should have the correct value",
                expectedPage1Param10ParamValue, actualPage1Param10ParamValue);
        assertEquals("Param 11 on the second page should have the correct name",
                expectedPage1Param11ParamName, actualPage1Param11ParamName);
        assertEquals("Param 11 on the second page should have the correct value",
                expectedPage1Param11ParamValue, actualPage1Param11ParamValue);
        assertEquals("Param 12 on the second page should have the correct name",
                expectedPage1Param12ParamName, actualPage1Param12ParamName);
        assertEquals("Param 12 on the second page should have the correct value",
                expectedPage1Param12ParamValue, actualPage1Param12ParamValue);
        assertEquals("Param 13 on the second page should have the correct name",
                expectedPage1Param13ParamName, actualPage1Param13ParamName);
        assertEquals("Param 13 on the second page should have the correct value",
                expectedPage1Param13ParamValue, actualPage1Param13ParamValue);
        assertEquals("Param 14 on the second page should have the correct name",
                expectedPage1Param14ParamName, actualPage1Param14ParamName);
        assertEquals("Param 14 on the second page should have the correct value",
                expectedPage1Param14ParamValue, actualPage1Param14ParamValue);
        assertEquals("Param 15 on the second page should have the correct name",
                expectedPage1Param15ParamName, actualPage1Param15ParamName);
        assertEquals("Param 15 on the second page should have the correct value",
                expectedPage1Param15ParamValue, actualPage1Param15ParamValue);
        assertEquals("Param 16 on the second page should have the correct name",
                expectedPage1Param16ParamName, actualPage1Param16ParamName);
        assertEquals("Param 16 on the second page should have the correct value",
                expectedPage1Param16ParamValue, actualPage1Param16ParamValue);
        assertEquals("Param 17 on the second page should have the correct name",
                expectedPage1Param17ParamName, actualPage1Param17ParamName);
        assertEquals("Param 17 on the second page should have the correct value",
                expectedPage1Param17ParamValue, actualPage1Param17ParamValue);
        assertEquals("Param 18 on the second page should have the correct name",
                expectedPage1Param18ParamName, actualPage1Param18ParamName);
        assertEquals("Param 18 on the second page should have the correct value",
                expectedPage1Param18ParamValue, actualPage1Param18ParamValue);
        assertEquals("Param 19 on the second page should have the correct name",
                expectedPage1Param19ParamName, actualPage1Param19ParamName);
        assertEquals("Param 19 on the second page should have the correct value",
                expectedPage1Param19ParamValue, actualPage1Param19ParamValue);
        assertEquals("Param 20 on the second page should have the correct name",
                expectedPage1Param20ParamName, actualPage1Param20ParamName);
        assertEquals("Param 20 on the second page should have the correct value",
                expectedPage1Param20ParamValue, actualPage1Param20ParamValue);
        assertEquals("Param 21 on the second page should have the correct name",
                expectedPage1Param21ParamName, actualPage1Param21ParamName);
        assertEquals("Param 21 on the second page should have the correct value",
                expectedPage1Param21ParamValue, actualPage1Param21ParamValue);
        assertEquals("Param 22 on the second page should have the correct name",
                expectedPage1Param22ParamName, actualPage1Param22ParamName);
        assertEquals("Param 22 on the second page should have the correct value",
                expectedPage1Param22ParamValue, actualPage1Param22ParamValue);
        assertEquals("Param 23 on the second page should have the correct name",
                expectedPage1Param23ParamName, actualPage1Param23ParamName);
        assertEquals("Param 23 on the second page should have the correct value",
                expectedPage1Param23ParamValue, actualPage1Param23ParamValue);
        assertEquals("Param 24 on the second page should have the correct name",
                expectedPage1Param24ParamName, actualPage1Param24ParamName);
        assertEquals("Param 24 on the second page should have the correct value",
                expectedPage1Param24ParamValue, actualPage1Param24ParamValue);
        assertEquals("Param 25 on the second page should have the correct name",
                expectedPage1Param25ParamName, actualPage1Param25ParamName);
        assertEquals("Param 25 on the second page should have the correct value",
                expectedPage1Param25ParamValue, actualPage1Param25ParamValue);
        assertEquals("Param 26 on the second page should have the correct name",
                expectedPage1Param26ParamName, actualPage1Param26ParamName);
        assertEquals("Param 26 on the second page should have the correct value",
                expectedPage1Param26ParamValue, actualPage1Param26ParamValue);
        assertEquals("Param 27 on the second page should have the correct name",
                expectedPage1Param27ParamName, actualPage1Param27ParamName);
        assertEquals("Param 27 on the second page should have the correct value",
                expectedPage1Param27ParamValue, actualPage1Param27ParamValue);
        assertEquals("Param 28 on the second page should have the correct name",
                expectedPage1Param28ParamName, actualPage1Param28ParamName);
        assertEquals("Param 28 on the second page should have the correct value",
                expectedPage1Param28ParamValue, actualPage1Param28ParamValue);
        assertEquals("Param 29 on the second page should have the correct name",
                expectedPage1Param29ParamName, actualPage1Param29ParamName);
        assertEquals("Param 29 on the second page should have the correct value",
                expectedPage1Param29ParamValue, actualPage1Param29ParamValue);
        assertEquals("Param 30 on the second page should have the correct name",
                expectedPage1Param30ParamName, actualPage1Param30ParamName);
        assertEquals("Param 30 on the second page should have the correct value",
                expectedPage1Param30ParamValue, actualPage1Param30ParamValue);
        assertEquals("Param 31 on the second page should have the correct name",
                expectedPage1Param31ParamName, actualPage1Param31ParamName);
        assertEquals("Param 31 on the second page should have the correct value",
                expectedPage1Param31ParamValue, actualPage1Param31ParamValue);
        assertEquals("Param 32 on the second page should have the correct name",
                expectedPage1Param32ParamName, actualPage1Param32ParamName);
        assertEquals("Param 32 on the second page should have the correct value",
                expectedPage1Param32ParamValue, actualPage1Param32ParamValue);
        assertEquals("Param 33 on the second page should have the correct name",
                expectedPage1Param33ParamName, actualPage1Param33ParamName);
        assertEquals("Param 33 on the second page should have the correct value",
                expectedPage1Param33ParamValue, actualPage1Param33ParamValue);
        assertEquals("Param 34 on the second page should have the correct name",
                expectedPage1Param34ParamName, actualPage1Param34ParamName);
        assertEquals("Param 34 on the second page should have the correct value",
                expectedPage1Param34ParamValue, actualPage1Param34ParamValue);
        assertEquals("Param 35 on the second page should have the correct name",
                expectedPage1Param35ParamName, actualPage1Param35ParamName);
        assertEquals("Param 35 on the second page should have the correct value",
                expectedPage1Param35ParamValue, actualPage1Param35ParamValue);
    }

    @Test
    public void testPdsExtractorServicePglFromScottFile() {
        // Arrange
        int expectedNumberOfPdsPages = 2;
        FileReaderService frService = new FileReaderService();
        List<String> lines = frService.readFile(pglFromScottFilePath);

        //Act
        PdsExtractorService service = new PdsExtractorService();
        List<PdsPage> pages = service.Extract(lines);

        //Assert
        assertEquals("There should be 2 pds pages present", expectedNumberOfPdsPages, pages.size());
    }

    @Test
    public void testPdsExtractorServiceEmptyPglThrowsException() {
        // Arrange
        boolean expectedExceptionEncountered = true;
        boolean actualExceptionEncountered = false;
        FileReaderService frService = new FileReaderService();
        List<String> lines = frService.readFile(emptyPglFilePath);

        //Act
        PdsExtractorService service = new PdsExtractorService();
        try {
            service.Extract(lines);
            fail("An exception should have been thrown as the file was empty");
        } catch (PdsExtractionFailedException e) {
            actualExceptionEncountered = true;
        }

        //Assert
        assertEquals("An exception should have been thrown as the pgl file was empty",
                expectedExceptionEncountered, actualExceptionEncountered);
    }

    @Test
    public void testPdsExtractorServiceNonsensePglThrowsException() {
        // Arrange
        boolean expectedExceptionEncountered = true;
        boolean actualExceptionEncountered = false;
        FileReaderService frService = new FileReaderService();
        List<String> lines = frService.readFile(nonsensePglFilePath);

        //Act
        PdsExtractorService service = new PdsExtractorService();
        try {
            service.Extract(lines);
            fail("An exception should have been thrown as the file was not a valid pgl file");
        } catch (PdsExtractionFailedException e) {
            actualExceptionEncountered = true;
        }

        //Assert
        assertEquals("An exception should have been thrown as the pgl file was empty",
                expectedExceptionEncountered, actualExceptionEncountered);
    }
}
