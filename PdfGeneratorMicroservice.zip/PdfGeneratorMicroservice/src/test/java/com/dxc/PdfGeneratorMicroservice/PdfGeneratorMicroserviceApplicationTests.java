package com.dxc.PdfGeneratorMicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfGeneratorMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
