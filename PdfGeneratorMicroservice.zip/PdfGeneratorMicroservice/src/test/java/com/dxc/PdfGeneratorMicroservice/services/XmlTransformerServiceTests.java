package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.models.PdsPage;
import org.junit.Test;
import org.w3c.dom.Document;

import java.util.List;

import static org.junit.Assert.assertTrue;

public class XmlTransformerServiceTests {
    private String fourFormsFileFilePath = "src/test/files/services/xmlTransformerService/FourForms.txt";

    @Test
    public void testXmlTransformerService() {
        // Arrange
        FileReaderService frService = new FileReaderService();
        List<String> lines = frService.readFile(fourFormsFileFilePath);
        PdsExtractorService peService = new PdsExtractorService();
        List<PdsPage> pages = peService.Extract(lines);
        FileWriterService fwService = new FileWriterService();

        //Act
        XmlTransformerService service = new XmlTransformerService();
        Document xmlDocument = service.generateXML(pages);
        fwService.writeFile(xmlDocument,
                "C:\\Users\\jdurrant3\\IdeaProjects\\FopProofOfConcept\\src\\main\\resources\\Results.xml");

        //Assert
        assertTrue(true);
    }
}
