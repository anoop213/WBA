package com.dxc.PdfGeneratorMicroservice.services;

import org.junit.Test;

import java.util.UUID;

import static org.junit.Assert.assertEquals;

public class ErrorServiceTests {
    private String unspecifiedErrorMessage = "Unspecified error message";

    @Test
    public void testGetErrorMessageNonePresent() {
        // Arrange
        String cupsId = UUID.randomUUID().toString();
        String expectedErrorMessage = unspecifiedErrorMessage;
        ErrorService service = ErrorService.getInstance();

        //Act
        String actualErrorMessage = service.getMessage(cupsId);

        // Assert
        assertEquals("The error message should be correct",
                expectedErrorMessage, actualErrorMessage);
    }

    @Test
    public void testPutErrorMessage() {
        // Arrange
        String cupsId = UUID.randomUUID().toString();
        String expectedErrorMessage = "ERROR";
        ErrorService service = ErrorService.getInstance();
        service.putMessage(cupsId, expectedErrorMessage);

        //Act
        String actualErrorMessage = service.getMessage(cupsId);

        // Assert
        assertEquals("The error message should be correct",
                expectedErrorMessage, actualErrorMessage);
    }

    @Test
    public void testPutErrorMessageMultipleUses() {
        // Arrange
        String cupsId1 = UUID.randomUUID().toString();
        String cupsId2 = UUID.randomUUID().toString();
        String cupsId3 = UUID.randomUUID().toString();
        String expectedErrorMessage1 = "ERROR1";
        String expectedErrorMessage2 = "ERROR2";
        String expectedErrorMessage3 = unspecifiedErrorMessage;
        ErrorService service = ErrorService.getInstance();
        service.putMessage(cupsId1, expectedErrorMessage1);
        service.putMessage(cupsId2, expectedErrorMessage2);

        //Act
        String actualErrorMessage1 = service.getMessage(cupsId1);
        String actualErrorMessage2 = service.getMessage(cupsId2);
        String actualErrorMessage3 = service.getMessage(cupsId3);

        // Assert
        assertEquals("The error message should be correct",
                expectedErrorMessage1, actualErrorMessage1);
        assertEquals("The error message should be correct",
                expectedErrorMessage2, actualErrorMessage2);
        assertEquals("The error message should be correct",
                expectedErrorMessage3, actualErrorMessage3);
    }

    @Test
    public void testHasErrorMessageNonePresent() {
        // Arrange
        String cupsId = UUID.randomUUID().toString();
        boolean expectedHasErrorMessage = false;
        ErrorService service = ErrorService.getInstance();

        //Act
        boolean actualHasErrorMessage = service.hasError(cupsId);

        // Assert
        assertEquals("The error message should be correct",
                expectedHasErrorMessage, actualHasErrorMessage);
    }

    @Test
    public void testHasErrorMessageErrorPresent() {
        // Arrange
        String cupsId = UUID.randomUUID().toString();
        String errorMessage = "Error";
        boolean expectedHasErrorMessage = true;
        ErrorService service = ErrorService.getInstance();
        service.putMessage(cupsId, errorMessage);

        //Act
        boolean actualHasErrorMessage = service.hasError(cupsId);

        // Assert
        assertEquals("The error message should be correct",
                expectedHasErrorMessage, actualHasErrorMessage);
    }
}
