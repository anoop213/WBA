package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.Config;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class TempFilesCleanupServiceTests {
    private String tempDirectoryNoFilesToRemove = "src/test/files/services/tempFilesCleanupService/noPdfsDirectory";
    private String tempDirectoryAllFilesToRemove = "src/test/files/services/tempFilesCleanupService/allPdfsDirectory";
    private String tempDirectoryMixedFilesToRemove = "src/test/files/services/tempFilesCleanupService/mixedPdfsDirectory";

    @Test
    public void testCleanOldPdfsNoneToRemove() {
        // Arrange
        int expectedNumberOfRemainingFiles = 3;
        int expectedNumberOfPriorFiles = 3;
        Config config = new Config();
        config.tempDirectory = tempDirectoryNoFilesToRemove;
        TempFilesCleanupService service = new TempFilesCleanupService(config);
        FileScannerService fsService = new FileScannerService(config);
        int actualNumberOfPriorFiles = fsService.scanTempDirectory().size();

        //Act
        service.cleanOldPdfs();
        int actualNumberOfRemainingFiles = fsService.scanTempDirectory().size();

        //Assert
        assertEquals("The right number of prior files should be present",
                expectedNumberOfPriorFiles, actualNumberOfPriorFiles);
        assertEquals("No files should have been deleted",
                expectedNumberOfRemainingFiles,actualNumberOfRemainingFiles);
    }

    @Test
    public void testCleanOldPdfsAllPdfsToRemove() {
        // Arrange
        int expectedNumberOfRemainingFiles = 0;
        int expectedNumberOfPriorFiles = 3;
        String fistFileFilename = String.format("%s/File1.pdf", tempDirectoryAllFilesToRemove);
        String secondFileFilename = String.format("%s/File2.pdf", tempDirectoryAllFilesToRemove);
        String thirdFileFilename = String.format("%s/File3.pdf", tempDirectoryAllFilesToRemove);
        Config config = new Config();
        config.tempDirectory = tempDirectoryAllFilesToRemove;
        TempFilesCleanupService service = new TempFilesCleanupService(config);
        FileWriterService fwService = new FileWriterService();
        FileScannerService fsService = new FileScannerService(config);
        List<String> fileContents = new ArrayList<>();
        fwService.writeFile(fileContents, fistFileFilename);
        fwService.writeFile(fileContents, secondFileFilename);
        fwService.writeFile(fileContents, thirdFileFilename);
        int actualNumberOfPriorFiles = fsService.scanTempDirectory().size();

        //Act
        service.cleanOldPdfs();
        int actualNumberOfRemainingFiles = fsService.scanTempDirectory().size();

        //Assert
        assertEquals("The right number of prior files should be present",
                expectedNumberOfPriorFiles, actualNumberOfPriorFiles);
        assertEquals("All the files created should have been deleted",
                expectedNumberOfRemainingFiles,actualNumberOfRemainingFiles);
    }

    @Test
    public void testCleanOldPdfsMixedPdfsToRemove() {
        // Arrange
        int expectedNumberOfRemainingFiles = 1;
        int expectedNumberOfPriorFiles = 3;
        String secondFileFilename = String.format("%s/File2.pdf", tempDirectoryMixedFilesToRemove);
        String thirdFileFilename = String.format("%s/File3.pdf", tempDirectoryMixedFilesToRemove);
        Config config = new Config();
        config.tempDirectory = tempDirectoryMixedFilesToRemove;
        TempFilesCleanupService service = new TempFilesCleanupService(config);
        FileWriterService fwService = new FileWriterService();
        FileScannerService fsService = new FileScannerService(config);
        List<String> fileContents = new ArrayList<>();
        fwService.writeFile(fileContents, secondFileFilename);
        fwService.writeFile(fileContents, thirdFileFilename);
        int actualNumberOfPriorFiles = fsService.scanTempDirectory().size();

        //Act
        service.cleanOldPdfs();
        int actualNumberOfRemainingFiles = fsService.scanTempDirectory().size();

        //Assert
        assertEquals("The right number of prior files should be present",
                expectedNumberOfPriorFiles, actualNumberOfPriorFiles);
        assertEquals("All the pdf files should have been deleted",
                expectedNumberOfRemainingFiles,actualNumberOfRemainingFiles);
    }
}
