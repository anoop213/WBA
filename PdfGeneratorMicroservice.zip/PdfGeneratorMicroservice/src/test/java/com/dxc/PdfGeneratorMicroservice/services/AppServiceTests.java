package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.Config;
import com.dxc.PdfGeneratorMicroservice.models.Job;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class AppServiceTests {
    private String happyPathPglFileFilename = "src/test/files/services/appService/happyPath/pgl.txt";
    private String happyPathPglFileFilenameCopy = "src/test/files/services/appService/happyPath/pglCopy.txt";
    private String happyPathPdfFilepath = "src/test/files/services/appService/happyPath/output.pdf";
    private String happyPathCmInputFileFilepath = "src/test/files/services/appService/happyPath/cmInput.inf";
    private String happyPathCmInputFileFilepathCopy = "src/test/files/services/appService/happyPath/cmInputCopy.inf";
    private String happyPathCmOutputFilepath = "src/test/files/services/appService/happyPath/cmOutput.inf";
    private String happyPathControlFile = "src/test/files/services/appService/happyPath/c1.json";
    private String happyPathControlFileCopy = "src/test/files/services/appService/happyPath/c1copy.json";
    private String missingPglPathPglFileFilename = "src/test/files/services/appService/missingPglPath/pgl.txt";
    private String missingPglPathPglFileFilenameCopy = "src/test/files/services/appService/missingPglPath/pglCopy.txt";
    private String missingPglPathPdfFilepath = "src/test/files/services/appService/missingPglPath/output.pdf";
    private String missingPglPathCmInputFileFilepath = "src/test/files/services/appService/missingPglPath/cmInput.inf";
    private String missingPglPathCmInputFileFilepathCopy = "src/test/files/services/appService/missingPglPath/cmInputCopy.inf";
    private String missingPglPathCmOutputFilepath = "src/test/files/services/appService/missingPglPath/cmOutput.inf";
    private String missingPglPathControlFile = "src/test/files/services/appService/missingPglPath/c1.json";
    private String missingPglPathControlFileCopy = "src/test/files/services/appService/missingPglPath/c1copy.json";
    private String missingCmInputPathPglFileFilename = "src/test/files/services/appService/missingCmInputPath/pgl.txt";
    private String missingCmInputPathPglFileFilenameCopy = "src/test/files/services/appService/missingCmInputPath/pglCopy.txt";
    private String missingCmInputPathPdfFilepath = "src/test/files/services/appService/missingCmInputPath/output.pdf";
    private String missingCmInputPathCmInputFileFilepath = "src/test/files/services/appService/missingCmInputPath/cmInput.inf";
    private String missingCmInputPathCmInputFileFilepathCopy = "src/test/files/services/appService/missingCmInputPath/cmInputCopy.inf";
    private String missingCmInputPathCmOutputFilepath = "src/test/files/services/appService/missingCmInputPath/cmOutput.inf";
    private String missingCmInputPathControlFile = "src/test/files/services/appService/missingCmInputPath/c1.json";
    private String missingCmInputPathControlFileCopy = "src/test/files/services/appService/missingCmInputPath/c1copy.json";
    private String samplePgl2Inch = "src/test/files/services/appService/2inPglFile.txt";
    private String samplePgl3Inch = "src/test/files/services/appService/3inPglFile.txt";
    private String samplePgl4Inch = "src/test/files/services/appService/4inPglFile.txt";
    private String samplePgl8Inch = "src/test/files/services/appService/8inPglFile.txt";

    @Test
    public void testRunHappyPath() {
        // Arrange
        boolean expectedPdfGenerated = true;
        boolean expectedHasError = false;
        String cupsUuid = "48a5a106-6737-4acb-b269-c45620aa9a1a";
        String sdmUuid = "9c9053f0-1d13-4f23-aa37-b6cd890ff37e";
        String pglFileFilename = happyPathPglFileFilename;
        String pdfFilepath = happyPathPdfFilepath;
        String cmInputFileFilepath = happyPathCmInputFileFilepath;
        String cmOutputFilepath = happyPathCmOutputFilepath;
        Job job = new Job(cupsUuid, sdmUuid, pglFileFilename,pdfFilepath,cmInputFileFilepath,cmOutputFilepath);
        Config config = new Config();
        config.sharedDirectory = "";
        config.tempDirectory = "";
        AppService service = new AppService(job, config, happyPathControlFile);
        FileWriterService fwService = new FileWriterService();
        fwService.copyFile(happyPathControlFileCopy, happyPathControlFile);
        fwService.copyFile(happyPathCmInputFileFilepathCopy, happyPathCmInputFileFilepath);
        fwService.copyFile(happyPathPglFileFilenameCopy, pglFileFilename);
        FileReaderService frService = new FileReaderService();
        fwService.deleteFile(happyPathPdfFilepath);
        fwService.deleteFile(cmOutputFilepath);

        //Act
        service.run();
        int sizeOdOutputPdf = frService.getFileSize(pdfFilepath);
        boolean actualPdfGenerated = sizeOdOutputPdf > 1000;
        ErrorService errorService = ErrorService.getInstance();
        boolean actualHasError = errorService.hasError(cupsUuid);

        // Assert
        assertEquals("The pdf file should have been generated",
                expectedPdfGenerated, actualPdfGenerated);
        assertEquals("No errors should have been recorded by the errors service",
                expectedHasError, actualHasError);
    }

    @Test
    public void testRunMissingPglPath() {
        // Arrange
        boolean expectedPdfGenerated = false;
        boolean expectedHasError = true;
        String expectedErrorMessage =
                "There was no Pgl file to read for the job at the following location: src/test/files/services/appService/missingPglPath/pgl.txt";
        String cupsUuid = "06d4e629-0e1a-4d40-85ef-86e7fd0e172e";
        String sdmUuid = "aa878c86-68fe-4e42-b2e1-7909abf5c5f8";
        String pglFileFilename = missingPglPathPglFileFilename;
        String pdfFilepath = missingPglPathPdfFilepath;
        String cmInputFileFilepath = missingPglPathCmInputFileFilepath;
        String cmOutputFilepath = missingPglPathCmOutputFilepath;
        Job job = new Job(cupsUuid, sdmUuid, pglFileFilename,pdfFilepath,cmInputFileFilepath,cmOutputFilepath);
        Config config = new Config();
        config.sharedDirectory = "";
        config.tempDirectory = "";
        AppService service = new AppService(job, config, missingPglPathControlFile);
        FileWriterService fwService = new FileWriterService();
        fwService.copyFile(missingPglPathControlFileCopy, missingPglPathControlFile);
        fwService.copyFile(missingPglPathCmInputFileFilepathCopy, missingPglPathCmInputFileFilepath);
        FileReaderService frService = new FileReaderService();
        fwService.deleteFile(missingPglPathPdfFilepath);
        fwService.deleteFile(cmOutputFilepath);

        //Act
        service.run();
        boolean actualPdfGenerated = frService.checkFileExists(pdfFilepath);
        ErrorService errorService = ErrorService.getInstance();
        boolean actualHasError = errorService.hasError(cupsUuid);
        String actualErrorMessage = errorService.getMessage(cupsUuid);

        // Assert
        assertEquals("The pdf file should not have been generated",
                expectedPdfGenerated, actualPdfGenerated);
        assertEquals("An error should have been recorded by the errors service",
                expectedHasError, actualHasError);
        assertEquals("The right error message should have been recorded",
                expectedErrorMessage, actualErrorMessage);
    }

    @Test
    public void testRunMissingCmInputPath() {
        // Arrange
        boolean expectedPdfGenerated = false;
        boolean expectedHasError = true;
        String expectedErrorMessage =
                "There was no Content Manger Input file to read for the job at the following location: src/test/files/services/appService/missingCmInputPath/cmInput.inf";
        String cupsUuid = "e9e05224-1efa-4f7c-a453-e2102fa95fad";
        String sdmUuid = "0e3a48fd-c7b6-48df-8576-073db3a0e0bb";
        String pglFileFilename = missingCmInputPathPglFileFilename;
        String pdfFilepath = missingCmInputPathPdfFilepath;
        String cmInputFileFilepath = missingCmInputPathCmInputFileFilepath;
        String cmOutputFilepath = missingCmInputPathCmOutputFilepath;
        Job job = new Job(cupsUuid, sdmUuid, pglFileFilename,pdfFilepath,cmInputFileFilepath,cmOutputFilepath);
        Config config = new Config();
        config.sharedDirectory = "";
        config.tempDirectory = "";
        AppService service = new AppService(job, config, missingCmInputPathControlFile);
        FileWriterService fwService = new FileWriterService();
        fwService.copyFile(missingCmInputPathControlFileCopy, missingCmInputPathControlFile);
        fwService.copyFile(missingCmInputPathPglFileFilenameCopy, pglFileFilename);
        FileReaderService frService = new FileReaderService();
        fwService.deleteFile(missingCmInputPathPdfFilepath);
        fwService.deleteFile(cmOutputFilepath);

        //Act
        service.run();
        boolean actualPdfGenerated = frService.checkFileExists(pdfFilepath);
        ErrorService errorService = ErrorService.getInstance();
        boolean actualHasError = errorService.hasError(cupsUuid);
        String actualErrorMessage = errorService.getMessage(cupsUuid);

        // Assert
        assertEquals("The pdf file should not have been generated",
                expectedPdfGenerated, actualPdfGenerated);
        assertEquals("An error should have been recorded by the errors service",
                expectedHasError, actualHasError);
        assertEquals("The right error message should have been recorded",
                expectedErrorMessage, actualErrorMessage);
    }

    @Test
    public void testTextFile2In() {
        // Arrange
        String expectedXslFileToUse = "2in.xsl";
        Job job = new Job();
        Config config = new Config();
        String controlFileFilepath = "";
        String pglFilename = samplePgl2Inch;
        AppService service = new AppService(job, config, controlFileFilepath);

        //Act
        String actualXslFileToUse = service.getXslFileToUse(pglFilename);

        //Assert
        assertEquals("The right xsl filename should have been determined",
                expectedXslFileToUse, actualXslFileToUse);
    }

    @Test
    public void testTextFile3In() {
        // Arrange
        String expectedXslFileToUse = "3in.xsl";
        Job job = new Job();
        Config config = new Config();
        String controlFileFilepath = "";
        String pglFilename = samplePgl3Inch;
        AppService service = new AppService(job, config, controlFileFilepath);

        //Act
        String actualXslFileToUse = service.getXslFileToUse(pglFilename);

        //Assert
        assertEquals("The right xsl filename should have been determined",
                expectedXslFileToUse, actualXslFileToUse);
    }

    @Test
    public void testTextFile4In() {
        // Arrange
        String expectedXslFileToUse = "4in.xsl";
        Job job = new Job();
        Config config = new Config();
        String controlFileFilepath = "";
        String pglFilename = samplePgl4Inch;
        AppService service = new AppService(job, config, controlFileFilepath);

        //Act
        String actualXslFileToUse = service.getXslFileToUse(pglFilename);

        //Assert
        assertEquals("The right xsl filename should have been determined",
                expectedXslFileToUse, actualXslFileToUse);
    }

    @Test
    public void testTextFile8In() {
        // Arrange
        String expectedXslFileToUse = "8in.xsl";
        Job job = new Job();
        Config config = new Config();
        String controlFileFilepath = "";
        String pglFilename = samplePgl8Inch;
        AppService service = new AppService(job, config, controlFileFilepath);

        //Act
        String actualXslFileToUse = service.getXslFileToUse(pglFilename);

        //Assert
        assertEquals("The right xsl filename should have been determined",
                expectedXslFileToUse, actualXslFileToUse);
    }
}
