package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.exceptions.FailureToReadControlFile;
import com.dxc.PdfGeneratorMicroservice.exceptions.FailureToReadXslConfigFileException;
import com.dxc.PdfGeneratorMicroservice.exceptions.NoFileToReadException;
import com.dxc.PdfGeneratorMicroservice.models.Job;
import com.dxc.PdfGeneratorMicroservice.models.XslConfig;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class FileReaderServiceTests {
    private String textFileFilePath = "src/test/files/services/fileReaderService/Text.txt";
    private String twoFormsFileFilePath = "src/test/files/services/fileReaderService/TwoForms.txt";
    private String emptyFileFilePath = "src/test/files/services/fileReaderService/EmptyFile.txt";
    private String nonExistantFilePath = "src/test/files/services/fileReaderService/DoesNotExist.txt";
    private String controlFileFilePath = "src/test/files/services/fileReaderService/ControlFile.json";
    private String xslConfigFileFilePath = "src/test/files/services/fileReaderService/XslConfig.json";

    @Test
    public void testReadFileTextFile() {
        // Arrange
        int expectedNumberOfLines = 1;
        String expectedFirstLine = "Hello";
        FileReaderService service = new FileReaderService();

        //Act
        List<String> lines = service.readFile(textFileFilePath);

        //Assert
        assertEquals("There should be one line in the file", expectedNumberOfLines, lines.size());
        assertEquals("The right first line should be present", expectedFirstLine, lines.get(0));
    }

    @Test
    public void testReadFileTwoFormsFile() {
        // Arrange
        int expectedNumberOfLines = 45;
        String expectedLineEight = "¬EXECUTE;TWNTRY";
        FileReaderService service = new FileReaderService();

        //Act
        List<String> lines = service.readFile(twoFormsFileFilePath);

        //Assert
        assertEquals("There should be 45 lines in the file", expectedNumberOfLines, lines.size());
        assertEquals("Line 8 should be present", expectedLineEight, lines.get(7));
    }

    @Test
    public void testReadFileEmptyFile() {
        // Arrange
        int expectedNumberOfLines = 0;
        FileReaderService service = new FileReaderService();

        //Act
        List<String> lines = service.readFile(emptyFileFilePath);

        //Assert
        assertEquals("There should be 0 lines in the file", expectedNumberOfLines, lines.size());
    }

    @Test
    public void testReadFileNonExistentFile() {
        // Arrange
        boolean expectedExceptionEncountered = true;
        boolean actualExceptionEncountered = false;
        FileReaderService service = new FileReaderService();

        //Act
        try {
            service.readFile(nonExistantFilePath);
            fail("An exception should have been thrown as the file is nonexistent");
        } catch(NoFileToReadException e) {
            actualExceptionEncountered = true;
        }

        //Assert
        assertEquals("An exception should have been thrown",
                expectedExceptionEncountered, actualExceptionEncountered);
    }

    @Test
    public void testReadControlFile() {
        // Arrange
        int expectedNumberOfJobs = 1;
        String expectedCupsUuid = "26885b23-5248-47e3-839e-7816d7b46e14";
        String expectedSdmUuid = "a87b793d-3608-42e0-82a6-ddc2377755c0";
        String expectedPglFileFilename = "3inPgl.txt";
        String expectedPdfFilepath = "C:\\dev\\Java\\FopPoc\\test files\\input\\3inch\\Output\\3inPgl.pdf";
        String expectedCmInputFileFilepath = "C:\\dev\\Java\\FopPoc\\test files\\input\\3inPgl.INF";
        String expectedCmOutputFilepath = "C:\\dev\\Java\\FopPoc\\test files\\input\\3inch\\Output\\3inPgl.INF";
        FileReaderService service = new FileReaderService();

        //Act
        Job actualJob = service.readControlFile(controlFileFilePath);
        String actualCupsUuid = actualJob.cupsUuid;
        String actualSdmUuid = actualJob.sdmUuid;
        String actualPglFileFilename = actualJob.pglFileFilename;
        String actualPdfFilepath = actualJob.pdfFilepath;
        String actualInputFileFilepath = actualJob.cmInputFileFilepath;
        String actualCmOutputFilepath = actualJob.cmOutputFilepath;

        //Assert
        assertEquals("There should be the correct cups uuid",
                expectedCupsUuid, actualCupsUuid);
        assertEquals("There should be the correct sdm uuid",
                expectedSdmUuid, actualSdmUuid);
        assertEquals("There should be the correct pgl filename",
                expectedPglFileFilename, actualPglFileFilename);
        assertEquals("There should be the correct pdf filename",
                expectedPdfFilepath, actualPdfFilepath);
        assertEquals("There should be the correct content manager input filename",
                expectedCmInputFileFilepath, actualInputFileFilepath);
        assertEquals("There should be the correct content manager output filename",
                expectedCmOutputFilepath, actualCmOutputFilepath);
    }

    // we have moved away from multiple job control files
//    @Test
//    public void testReadControlFileLongFile() {
//        // Arrange
//        int expectedNumberOfJobs = 3;
//        FileReaderService service = new FileReaderService();
//
//        //Act
//        Job actualJob = service.readControlFile(longControlFileFilePath);
//
//        //Assert
//        assertEquals("There should be 3 jobs in the control file",
//                expectedNumberOfJobs, actualNumberOfJobs);
//    }

    @Test
    public void testReadControlFileEmptyFile() {
        // Arrange
        boolean expectedExceptionEncountered = true;
        boolean actualExceptionEncountered = false;
        FileReaderService service = new FileReaderService();

        //Act
        try {
            service.readControlFile(emptyFileFilePath);
            fail("An exception should have been thrown as the file is empty");
        } catch(FailureToReadControlFile e) {
            actualExceptionEncountered = true;
        }

        assertEquals("An exception should have been thrown",
                expectedExceptionEncountered, actualExceptionEncountered);
    }

    @Test
    public void testReadControlFileNonExistentFile() {
        // Arrange
        boolean expectedExceptionEncountered = true;
        boolean actualExceptionEncountered = false;
        FileReaderService service = new FileReaderService();

        //Act
        try {
            service.readControlFile(nonExistantFilePath);
            fail("An exception should have been thrown as the file is nonexistent");
        } catch(FailureToReadControlFile e) {
            actualExceptionEncountered = true;
        }

        //Assert
        assertEquals("An exception should have been thrown",
                expectedExceptionEncountered, actualExceptionEncountered);
    }

    @Test
    public void testReadXslConfigFile() {
        // Arrange
        int expectedNumberOfXslFiles = 26;
        FileReaderService service = new FileReaderService();

        //Act
        XslConfig actualXslConfig = service.readXslConfigFile(xslConfigFileFilePath);
        int actualNumberOfXslFiles = actualXslConfig.getCountOfXslFiles();

        //Assert
        assertEquals("There should be 26 defined xsl files",
                expectedNumberOfXslFiles, actualNumberOfXslFiles);
    }

    @Test
    public void testReadXslConfigFileEmptyFile() {
        // Arrange
        boolean expectedExceptionEncountered = true;
        boolean actualExceptionEncountered = false;
        FileReaderService service = new FileReaderService();

        //Act
        try {
            service.readXslConfigFile(emptyFileFilePath);
            fail("An exception should have been thrown as the file is empty");
        } catch(FailureToReadXslConfigFileException e) {
            actualExceptionEncountered = true;
        }

        assertEquals("An exception should have been thrown",
                expectedExceptionEncountered, actualExceptionEncountered);
    }

    @Test
    public void testReadXslConfigFileNonExistentFile() {
        // Arrange
        boolean expectedExceptionEncountered = true;
        boolean actualExceptionEncountered = false;
        FileReaderService service = new FileReaderService();

        //Act
        try {
            service.readXslConfigFile(nonExistantFilePath);
            fail("An exception should have been thrown as the file is nonexistent");
        } catch(FailureToReadXslConfigFileException e) {
            actualExceptionEncountered = true;
        }

        //Assert
        assertEquals("An exception should have been thrown",
                expectedExceptionEncountered, actualExceptionEncountered);
    }

    @Test
    public void testFileExistsExistingFile() {
        // Arrange
        boolean expectedFileExists = true;
        String existingFileFilePath = textFileFilePath;
        FileReaderService service = new FileReaderService();

        //Act
        boolean actualFileExists = service.checkFileExists(existingFileFilePath);

        //Assert
        assertEquals("The service should have determined that the file exists",
                expectedFileExists, actualFileExists);
    }

    @Test
    public void testFileExistsNonExistingFile() {
        // Arrange
        boolean expectedFileExists = false;
        String nonExistingFileFilePath = nonExistantFilePath;
        FileReaderService service = new FileReaderService();

        //Act
        boolean actualFileExists = service.checkFileExists(nonExistingFileFilePath);

        //Assert
        assertEquals("The service should have determined that the file does not exist",
                expectedFileExists, actualFileExists);
    }

    @Test
    public void testFileSizeExistingFile() {
        // Arrange
        int expectedFileSize = 5;
        String existingFileFilePath = textFileFilePath;
        FileReaderService service = new FileReaderService();

        //Act
        int actualFileSize = service.getFileSize(existingFileFilePath);

        //Assert
        assertEquals("The service should have determined the size of the file",
                expectedFileSize, actualFileSize);
    }

    @Test
    public void testFileSizeExistingFileBiggerFile() {
        // Arrange
        int expectedFileSize = 1409;
        String existingFileFilePath = xslConfigFileFilePath;
        FileReaderService service = new FileReaderService();

        //Act
        int actualFileSize = service.getFileSize(existingFileFilePath);

        //Assert
        assertEquals("The service should have determined the size of the file",
                expectedFileSize, actualFileSize);
    }

    @Test
    public void testFileSizeNonExistingFile() {
        boolean expectedExceptionEncountered = true;
        boolean actualExceptionEncountered = false;
        FileReaderService service = new FileReaderService();

        //Act
        try {
            service.getFileSize(nonExistantFilePath);
            fail("An exception should have been thrown as the file is nonexistent");
        } catch(NoFileToReadException e) {
            actualExceptionEncountered = true;
        }

        //Assert
        assertEquals("An exception should have been thrown",
                expectedExceptionEncountered, actualExceptionEncountered);
    }
}
