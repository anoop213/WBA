package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.exceptions.NoFileToCopyException;
import com.dxc.PdfGeneratorMicroservice.exceptions.NoFileToReadException;
import com.dxc.PdfGeneratorMicroservice.models.ControlFile;
import com.dxc.PdfGeneratorMicroservice.models.Job;
import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class FileWriterServiceTests {
    private String testDocumentFilePath = "src/test/files/services/fileWriterService/Document.xml";
    private String testTextFilePath = "src/test/files/services/fileWriterService/TextFile.txt";
    private String testControlFilePath = "src/test/files/services/fileWriterService/ControlFile.json";
    private String testFileToDeleteFilePath = "src/test/files/services/fileWriterService/toDelete.txt";
    private String testCopyInitialFilePath = "src/test/files/services/fileWriterService/toCopy.txt";
    private String testCopyFinalFilePath = "src/test/files/services/fileWriterService/copied.txt";
    private String testCopyNonExistentFilePath = "src/test/files/services/fileWriterService/doesNotExist.txt";

    @Test
    public void testWriteFileFromDocument() {
        // Arrange
        int expectedNumberOfLines = 1;
        String expectedFirstLine = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        FileWriterService service = new FileWriterService();
        FileReaderService readService = new FileReaderService();
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        Document document = null;
        try {
            DocumentBuilder db = dbf.newDocumentBuilder();
            document = db.newDocument();
            Element rootElement = document.createElement("labeldata");
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        service.deleteFile(testDocumentFilePath);

        //Act
        service.writeFile(document, testDocumentFilePath);
        List<String> actualLines = readService.readFile(testDocumentFilePath);
        int actualNumberOfLines = actualLines.size();
        String actualFirstLine = actualLines.get(0);

        //Assert
        assertEquals("There should be one line in the file", expectedNumberOfLines, actualNumberOfLines);
        assertEquals("The right first line should be present", expectedFirstLine, actualFirstLine);
    }

    @Test
    public void testWriteFileFromText() {
        // Arrange
        int expectedNumberOfLines = 3;
        String expectedFirstLine = "Line1";
        String expectedSecondLine = "Line2";
        String expectedThirdLine = "Line3";
        List<String> lines = Arrays.asList(expectedFirstLine, expectedSecondLine, expectedThirdLine);
        FileWriterService service = new FileWriterService();
        FileReaderService readService = new FileReaderService();
        service.deleteFile(testTextFilePath);

        //Act
        service.writeFile(lines, testTextFilePath);
        List<String> actualLines = readService.readFile(testTextFilePath);
        int actualNumberOfLines = actualLines.size();
        String actualFirstLine = actualLines.get(0);
        String actualSecondLine = actualLines.get(1);
        String actualThirdLine = actualLines.get(2);

        //Assert
        assertEquals("There should be 3 lines in the file", expectedNumberOfLines, actualNumberOfLines);
        assertEquals("The right first line should be present", expectedFirstLine, actualFirstLine);
        assertEquals("The right second line should be present", expectedSecondLine, actualSecondLine);
        assertEquals("The right third line should be present", expectedThirdLine, actualThirdLine);
    }

    @Test
    public void testWriteControlFile() {
        // Arrange
        int expectedNumberOfJobs = 3;
        ControlFile controlFile = new ControlFile();
        String expectedJobPglName = "Pgl 1";
        Job job = new Job("", "", expectedJobPglName,"","","");
        controlFile.job = job;
        FileWriterService service = new FileWriterService();
        FileReaderService readService = new FileReaderService();
        service.deleteFile(testControlFilePath);

        //Act
        service.writeControlFile(controlFile, testControlFilePath);
        Job actualJob = readService.readControlFile(testControlFilePath);
        String actualJobPglName = actualJob.pglFileFilename;

        //Assert
        assertEquals("The right job pgl name should be present", expectedJobPglName, actualJobPglName);
    }

    @Test
    public void testDeleteFile() {
        // Arrange
        boolean expectedExceptionEncountered = true;
        boolean actualExceptionEncountered = false;
        FileWriterService service = new FileWriterService();
        FileReaderService readService = new FileReaderService();
        List<String> lines = Arrays.asList("Line 1", "Line 2", "Line 3");
        service.writeFile(lines, testFileToDeleteFilePath);

        //Act
        service.deleteFile(testFileToDeleteFilePath);
        try {
            readService.readFile(testFileToDeleteFilePath);
            fail("An exception should have been thrown");
        } catch(NoFileToReadException e) {
            actualExceptionEncountered = true;
        }

        //Assert
        assertEquals("An exception should have been encountered",
                expectedExceptionEncountered, actualExceptionEncountered);
    }

    @Test
    public void testCopyFile() {
        // Arrange
        String initialFilePath = testCopyInitialFilePath;
        String finalFilePath = testCopyFinalFilePath;
        int expectedNumberOfLines = 3;
        String expectedFirstLine = "Line 1";
        String expectedSecondLine = "Line 2";
        String expectedThirdLine = "Line 3";
        FileWriterService service = new FileWriterService();
        FileReaderService readService = new FileReaderService();
        List<String> lines = Arrays.asList("Line 1", "Line 2", "Line 3");
        service.writeFile(lines, testCopyInitialFilePath);
        service.deleteFile(finalFilePath);

        //Act
        service.copyFile(initialFilePath, finalFilePath);
        List<String> actualLines = readService.readFile(finalFilePath);
        int actualNumberOfLines = actualLines.size();
        String actualFirstLine = actualLines.get(0);
        String actualSecondLine = actualLines.get(1);
        String actualThirdLine = actualLines.get(2);

        //Assert
        assertEquals("There should be 3 lines in the copied file", expectedNumberOfLines, actualNumberOfLines);
        assertEquals("The right first line should be present", expectedFirstLine, actualFirstLine);
        assertEquals("The right second line should be present", expectedSecondLine, actualSecondLine);
        assertEquals("The right third line should be present", expectedThirdLine, actualThirdLine);
    }

    @Test
    public void testCopyFileOriginalFileNotPresent() {
        // Arrange
        String initialFilePath = testCopyNonExistentFilePath;
        String finalFilePath = testCopyFinalFilePath;
        boolean expectedExceptionEncountered = true;
        boolean actualExceptionEncountered = false;
        FileWriterService service = new FileWriterService();
        List<String> lines = Arrays.asList("Line 1", "Line 2", "Line 3");
        service.writeFile(lines, testFileToDeleteFilePath);

        //Act
        try {
            service.copyFile(initialFilePath, finalFilePath);
            fail("An exception should have been thrown");
        } catch(NoFileToCopyException e) {
            actualExceptionEncountered = true;
        }

        //Assert
        assertEquals("An exception should have been encountered",
                expectedExceptionEncountered, actualExceptionEncountered);
    }
}
