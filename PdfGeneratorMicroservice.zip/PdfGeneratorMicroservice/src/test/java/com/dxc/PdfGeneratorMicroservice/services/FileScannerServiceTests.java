package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.Config;
import com.dxc.PdfGeneratorMicroservice.exceptions.DirectoryDoesNotExistException;
import org.junit.Test;

import java.io.File;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class FileScannerServiceTests {
    @Test
    public void testFileScannerScanNoParameterEmptySharedDirectory() {
        // Arrange
        int expectedNumberOfFiles = 0;
        String emptyDirectoryPath = "src/test/files/services/fileScannerService/emptyDirectory";
        Config config = new Config();
        config.sharedDirectory = emptyDirectoryPath;
        FileScannerService service = new FileScannerService(config);

        //Act
        List<File> files = service.scanSharedDirectory();

        //Assert
        assertEquals("There should be no files found in the directory", expectedNumberOfFiles, files.size());
    }

    @Test
    public void testFileScannerScanNoParameterEmptySharedDirectoryDodgyConfig() {
        // Arrange
        boolean expectedExceptionThrown = true;
        boolean actualExceptionThrown = false;
        String emptyDirectoryPath = "DOES_NOT_EXIST";
        Config config = new Config();
        config.sharedDirectory = emptyDirectoryPath;
        FileScannerService service = new FileScannerService(config);

        //Act
        try {
            service.scanSharedDirectory();
        } catch (DirectoryDoesNotExistException e) {
            actualExceptionThrown = true;
        }

        //Assert
        assertEquals("An exception should have been thrown", expectedExceptionThrown, actualExceptionThrown);
    }

    @Test
    public void testFileScannerScanPassedParameterEmptySharedDirectory() {
        // Arrange
        int expectedNumberOfFiles = 0;
        String fileSuffix = ".json";
        String emptyDirectoryPath = "src/test/files/services/fileScannerService/emptyDirectory";
        Config config = new Config();
        config.sharedDirectory = emptyDirectoryPath;
        FileScannerService service = new FileScannerService(config);

        //Act
        List<File> files = service.scanSharedDirectory(fileSuffix);

        //Assert
        assertEquals("There should be no files found in the directory", expectedNumberOfFiles, files.size());
    }

    @Test
    public void testFileScannerScanPassedParameterEmptySharedDirectoryDodgyConfig() {
        // Arrange
        boolean expectedExceptionThrown = true;
        boolean actualExceptionThrown = false;
        String fileSuffix = ".json";
        String emptyDirectoryPath = "DOES_NOT_EXIST";
        Config config = new Config();
        config.sharedDirectory = emptyDirectoryPath;
        FileScannerService service = new FileScannerService(config);

        //Act
        try {
            service.scanSharedDirectory(fileSuffix);
        } catch (DirectoryDoesNotExistException e) {
            actualExceptionThrown = true;
        }

        //Assert
        assertEquals("An exception should have been thrown", expectedExceptionThrown, actualExceptionThrown);
    }

    @Test
    public void testFileScannerScanPassedParameterNoXmlSharedDirectoryFindsNoXml() {
        // Arrange
        int expectedNumberOfFiles = 0;
        String fileSuffix = ".xml";
        String emptyDirectoryPath = "src/test/files/services/fileScannerService/noXml";
        Config config = new Config();
        config.sharedDirectory = emptyDirectoryPath;
        FileScannerService service = new FileScannerService(config);

        //Act
        List<File> files = service.scanSharedDirectory(fileSuffix);

        //Assert
        assertEquals("There should be no files found in the directory", expectedNumberOfFiles, files.size());
    }

    @Test
    public void testFileScannerScanPassedParameterNoXmlSharedDirectoryFindsTwoJson() {
        // Arrange
        int expectedNumberOfFiles = 2;
        String fileSuffix = ".json";
        String emptyDirectoryPath = "src/test/files/services/fileScannerService/noXml";
        Config config = new Config();
        config.sharedDirectory = emptyDirectoryPath;
        FileScannerService service = new FileScannerService(config);

        //Act
        List<File> files = service.scanSharedDirectory(fileSuffix);

        //Assert
        assertEquals("There should be two files found in the directory", expectedNumberOfFiles, files.size());
    }

    @Test
    public void testFileScannerScanPassedParameterNoXmlSharedDirectoryFindsOneHtml() {
        // Arrange
        int expectedNumberOfFiles = 1;
        String fileSuffix = ".html";
        String emptyDirectoryPath = "src/test/files/services/fileScannerService/noXml";
        Config config = new Config();
        config.sharedDirectory = emptyDirectoryPath;
        FileScannerService service = new FileScannerService(config);

        //Act
        List<File> files = service.scanSharedDirectory(fileSuffix);

        //Assert
        assertEquals("There should be one file found in the directory", expectedNumberOfFiles, files.size());
    }

    // *************** Temp Directory ***************

    @Test
    public void testFileScannerScanNoParameterEmptyTempDirectory() {
        // Arrange
        int expectedNumberOfFiles = 0;
        String emptyDirectoryPath = "src/test/files/services/fileScannerService/emptyDirectory";
        Config config = new Config();
        config.tempDirectory = emptyDirectoryPath;
        FileScannerService service = new FileScannerService(config);

        //Act
        List<File> files = service.scanTempDirectory();

        //Assert
        assertEquals("There should be no files found in the directory", expectedNumberOfFiles, files.size());
    }

    @Test
    public void testFileScannerScanNoParameterEmptyTempDirectoryDodgyConfig() {
        // Arrange
        boolean expectedExceptionThrown = true;
        boolean actualExceptionThrown = false;
        String emptyDirectoryPath = "DOES_NOT_EXIST";
        Config config = new Config();
        config.tempDirectory = emptyDirectoryPath;
        FileScannerService service = new FileScannerService(config);

        //Act
        try {
            service.scanTempDirectory();
        } catch (DirectoryDoesNotExistException e) {
            actualExceptionThrown = true;
        }

        //Assert
        assertEquals("An exception should have been thrown", expectedExceptionThrown, actualExceptionThrown);
    }

    @Test
    public void testFileScannerScanPassedParameterEmptyTempDirectory() {
        // Arrange
        int expectedNumberOfFiles = 0;
        String fileSuffix = ".json";
        String emptyDirectoryPath = "src/test/files/services/fileScannerService/emptyDirectory";
        Config config = new Config();
        config.tempDirectory = emptyDirectoryPath;
        FileScannerService service = new FileScannerService(config);

        //Act
        List<File> files = service.scanTempDirectory(fileSuffix);

        //Assert
        assertEquals("There should be no files found in the directory", expectedNumberOfFiles, files.size());
    }

    @Test
    public void testFileScannerScanPassedParameterEmptyTempDirectoryDodgyConfig() {
        // Arrange
        boolean expectedExceptionThrown = true;
        boolean actualExceptionThrown = false;
        String fileSuffix = ".json";
        String emptyDirectoryPath = "DOES_NOT_EXIST";
        Config config = new Config();
        config.tempDirectory = emptyDirectoryPath;
        FileScannerService service = new FileScannerService(config);

        //Act
        try {
            service.scanTempDirectory(fileSuffix);
        } catch (DirectoryDoesNotExistException e) {
            actualExceptionThrown = true;
        }

        //Assert
        assertEquals("An exception should have been thrown", expectedExceptionThrown, actualExceptionThrown);
    }

    @Test
    public void testFileScannerScanPassedParameterNoXmlTempDirectoryFindsNoXml() {
        // Arrange
        int expectedNumberOfFiles = 0;
        String fileSuffix = ".xml";
        String emptyDirectoryPath = "src/test/files/services/fileScannerService/noXml";
        Config config = new Config();
        config.tempDirectory = emptyDirectoryPath;
        FileScannerService service = new FileScannerService(config);

        //Act
        List<File> files = service.scanTempDirectory(fileSuffix);

        //Assert
        assertEquals("There should be no files found in the directory", expectedNumberOfFiles, files.size());
    }

    @Test
    public void testFileScannerScanPassedParameterNoXmlTempDirectoryFindsTwoJson() {
        // Arrange
        int expectedNumberOfFiles = 2;
        String fileSuffix = ".json";
        String emptyDirectoryPath = "src/test/files/services/fileScannerService/noXml";
        Config config = new Config();
        config.tempDirectory = emptyDirectoryPath;
        FileScannerService service = new FileScannerService(config);

        //Act
        List<File> files = service.scanTempDirectory(fileSuffix);

        //Assert
        assertEquals("There should be two files found in the directory", expectedNumberOfFiles, files.size());
    }

    @Test
    public void testFileScannerScanPassedParameterNoXmlTempDirectoryFindsOneHtml() {
        // Arrange
        int expectedNumberOfFiles = 1;
        String fileSuffix = ".html";
        String emptyDirectoryPath = "src/test/files/services/fileScannerService/noXml";
        Config config = new Config();
        config.tempDirectory = emptyDirectoryPath;
        FileScannerService service = new FileScannerService(config);

        //Act
        List<File> files = service.scanTempDirectory(fileSuffix);

        //Assert
        assertEquals("There should be one file found in the directory", expectedNumberOfFiles, files.size());
    }
}
