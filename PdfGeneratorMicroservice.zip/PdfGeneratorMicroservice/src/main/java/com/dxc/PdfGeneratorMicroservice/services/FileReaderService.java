package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.exceptions.FailureToReadControlFile;
import com.dxc.PdfGeneratorMicroservice.exceptions.FailureToReadXslConfigFileException;
import com.dxc.PdfGeneratorMicroservice.exceptions.NoFileToReadException;
import com.dxc.PdfGeneratorMicroservice.models.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FileReaderService {
    private Logger logger;

    public FileReaderService() {
        this.logger = LoggerFactory.getLogger(FileReaderService.class);
    }

    public List<String> readFile(String filePath) {
        logger.debug(String.format("File Reader Service reading file, filePath: %s", filePath));
        List<String> lines = new ArrayList<String>();

        try {
            File myObj = new File(filePath);
            //Scanner myReader = new Scanner(myObj, "UTF-8");
            Scanner myReader = new Scanner(myObj, "Cp1252");
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine().trim();
                // filter out mystery char
                char[] lineChars = data.toCharArray();
                StringBuilder sb = new StringBuilder();
                for(char c : lineChars) {
                    int i = (int) c;
                    if(i != 194) {
                        sb.append(c);
                    }
                }
                lines.add(sb.toString());
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            logger.error("File not found exception encountered");
            e.printStackTrace();
            String message = String.format("No file found to read, filepath: %S", filePath);
            throw new NoFileToReadException(message);
        }

        logger.debug("Finished reading file");
        return lines;
    }

    public Job readControlFile(String filePath) {
        logger.debug(String.format("File Reader Service reading control file, filePath: %s", filePath));
        ObjectMapper mapper = new ObjectMapper();

        try {
            ControlFile file = mapper.readValue(Paths.get(filePath).toFile(), ControlFile.class);
            return file.job;
        } catch (IOException e) {
            logger.error("IO Exception encountered reading control file");
        }

        logger.error("Throwing FailureToReadControlFile exception as control file could not be loaded");
        String message = String.format("Failure to read control file, filepath: %s", filePath);
        throw new FailureToReadControlFile(message);
    }

    public XslConfig readXslConfigFile(String filePath) {
        logger.debug(String.format("File Reader Service reading xsl config file, filePath: %s", filePath));
        ObjectMapper mapper = new ObjectMapper();

        XslConfigFile file = null;
        try {
            InputStream in = FileReaderService.class.getResourceAsStream("/" + filePath);
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            file = mapper.readValue(reader, XslConfigFile.class);
        } catch (NullPointerException e) {
            File inputFile = new File(filePath);
            try {
                file = mapper.readValue(Paths.get(filePath).toFile(), XslConfigFile.class);
            } catch (IOException e2) {
                logger.error("Failure reading xsl config file, throwing FailureToReadXslConfigFile exception");
                String message = String.format("Failure to read xsl config file, filepath: %s", filePath);
                throw new FailureToReadXslConfigFileException("Failure reading xsl config file");
            }
        } catch (IOException e) {
            logger.error("Failure reading xsl config file, throwing FailureToReadXslConfigFile exception");
            String message = String.format("Failure to read xsl config file, filepath: %s", filePath);
            throw new FailureToReadXslConfigFileException("Failure reading xsl config file");
        }

        XslConfig xslConfig = new XslConfig();

        for(XslConfigRecord record : file.config) {
            xslConfig.add(record.labelName, record.xslFileName);
        }

        logger.debug("Successfully read XSL Config File");
        return xslConfig;
    }

    public boolean checkFileExists(String filePath) {
        logger.debug(String.format("File Reader Service checking if file exists, filePath: %s", filePath));

        File file = new File(filePath);

        boolean fileExists = file.exists();
        logger.debug(String.format("File exists: %s", fileExists));

        logger.debug("File Reader Service successfully checked if file exists");
        return fileExists;
    }

    public int getFileSize(String filePath) {
        logger.debug(String.format("File Reader Service getting file size, filePath: %s", filePath));

        File file = new File(filePath);

        if(!file.exists()) {
            String errorMessage = String.format("The file does not exist at filepath: %s", filePath);
            throw new NoFileToReadException(errorMessage);
        }

        long fileSizeLong = file.length();
        int fileSize = (int) fileSizeLong;
        logger.debug(String.format("File size: %s", fileSize));

        logger.debug("File Reader Service successfully got file size");
        return fileSize;
    }

}