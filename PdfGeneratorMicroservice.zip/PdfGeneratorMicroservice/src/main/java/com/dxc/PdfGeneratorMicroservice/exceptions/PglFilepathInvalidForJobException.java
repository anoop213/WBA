package com.dxc.PdfGeneratorMicroservice.exceptions;

public class PglFilepathInvalidForJobException extends  RuntimeException {
    public PglFilepathInvalidForJobException(String errorMessage) {
        super(errorMessage);
    }
}
