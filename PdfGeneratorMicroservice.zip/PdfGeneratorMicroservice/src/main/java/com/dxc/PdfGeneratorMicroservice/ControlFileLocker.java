package com.dxc.PdfGeneratorMicroservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class ControlFileLocker {
    private static ControlFileLocker instance = null;
    private Map<String,Boolean> lockedFiles;
    private Logger logger;

    private ControlFileLocker() {
        this.lockedFiles = new HashMap<>();
        this.logger = LoggerFactory.getLogger(ControlFileLocker.class);
        logger.debug("Successfully constructed Control File Locker");
    }

    public synchronized static ControlFileLocker getInstance() {
        if(instance == null) {
           instance = new ControlFileLocker();
        }

        return instance;
    }

    public synchronized boolean lockControlFile(String controlFileName) {
        logger.debug(String.format("Locking control file, control file name: %s", controlFileName));
        if(lockedFiles.containsKey(controlFileName)) {
            logger.debug("File was already locked so returning false");
            return false;
        }

        lockedFiles.put(controlFileName, true);
        logger.debug("File successfully locked so returning true");
        return true;
    }

    public synchronized boolean unlockControlFile(String controlFileName) {
        logger.debug(String.format("Unlocking control file, control file name: %s", controlFileName));
        if(!lockedFiles.containsKey(controlFileName)) {
            logger.debug("File was already unlocked so returning false");
            return false;
        }

        lockedFiles.remove(controlFileName);
        logger.debug("File was successfully unlocked so returning true");
        return true;
    }
}
