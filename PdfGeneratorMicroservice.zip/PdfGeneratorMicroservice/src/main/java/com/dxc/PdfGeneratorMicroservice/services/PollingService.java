package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.Config;
import com.dxc.PdfGeneratorMicroservice.models.PollResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class PollingService {
    private static PollingService instance;
    private Config config;
    private Map<String, Boolean> completedJobs;
    private FileReaderService frService;
    private Logger logger;

    private PollingService(Config config, FileReaderService frService) {
        this.config = config;
        this.completedJobs = new HashMap<>();
        this.frService = frService;
        this.logger = LoggerFactory.getLogger(PollingService.class);
    }

    public static synchronized PollingService getInstance(Config config, FileReaderService frService) {
        if(instance == null) {
            instance = new PollingService(config, frService);
        }

        return instance;
    }

    public synchronized PollResult poll(String cupsUuid) {
        String controlFileName = String.format("%s/%s.json", config.sharedDirectory, cupsUuid);
        boolean stillInProgress = frService.checkFileExists(controlFileName);
        if(stillInProgress) {
            return PollResult.InProgress;
        }

        Boolean completed = this.completedJobs.get(cupsUuid);
        if(completed != null) {
            return PollResult.Completed;
        }

        ErrorService errorService = ErrorService.getInstance();
        boolean hasError = errorService.hasError(cupsUuid);
        if(hasError) {
            return PollResult.Failed;
        }

        return PollResult.Undefined;
    }

    public synchronized void setComplete(String cupsUuid) {
        logger.debug(String.format("Setting to complete job with cups uuid: %s", cupsUuid));
        completedJobs.put(cupsUuid, true);
        logger.debug("Successfully set the job to complete");
    }
}
