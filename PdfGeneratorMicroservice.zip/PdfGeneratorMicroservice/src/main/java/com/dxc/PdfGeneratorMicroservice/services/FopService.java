package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.Config;
import com.dxc.PdfGeneratorMicroservice.exceptions.*;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.MimeConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamSource;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FopService {
    private Logger logger;
    private Config config;

    public FopService(Config config) {
        this.logger = LoggerFactory.getLogger(FopService.class);
        this.config = config;
    }

    public void generatePdfForSpecifiedFiles(String xmlFilename, String xsltFilename, String pdfFilename) {
        logger.debug("Fop Service Generating PDF for Specified Files");

        try {
            logger.debug("FOP ExampleXML2PDF");
            logger.debug("Preparing...");

            // Setup input and output files
            File xmlFile = new File(xmlFilename);
            if (!xmlFile.exists()) {
                String errorMessage = String.format("No input xml file found, file path: %s", xmlFilename);
                logger.error(errorMessage);
                throw new NoXmlDataException(errorMessage);
            }
            this.throwExceptionIfXmlFileInvalid(xmlFile);

            BufferedReader xsltfile = null;
            // depending on whether we are running as a standalone jar accessing the xsl file is different
            try {
                InputStream xslIs = FopService.class.getResourceAsStream("/" + xsltFilename);
                xsltfile = new BufferedReader(new InputStreamReader(xslIs));
            } catch (NullPointerException e) {
                try {
                    xsltfile = new BufferedReader(new FileReader(xsltFilename));
                } catch (FileNotFoundException e1) {
                    String errorMessage = String.format("No input xsl file found, file path: %s", xsltFilename);
                    logger.error(errorMessage);
                    throw new NoXslTransformationException(errorMessage);
                }
            }

            File pdffile = new File(pdfFilename);

            logger.debug("Input: XML (" + xmlFile + ")");
            logger.debug("Stylesheet: " + xsltfile);
            logger.debug("Output: PDF (" + pdffile + ")");
            logger.debug("");
            logger.debug("Transforming...");



            // configure fopFactory as desired
            // final FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());
            // File configFile = new File("fopConfigOLD.xml");
            File fopConfigFile = createAndReturnTempFopConfigFile();
            final FopFactory fopFactory = FopFactory.newInstance(fopConfigFile);

            FOUserAgent foUserAgent = fopFactory.newFOUserAgent();
            // configure foUserAgent as desired

            // Setup output
            OutputStream out = null;
            try {
                out = new java.io.FileOutputStream(pdffile);
                out = new java.io.BufferedOutputStream(out);
            } catch (FileNotFoundException e) {
                String errorMessage = String.format("Illegal Pdf File Name Exception, name: %s", pdfFilename);
                logger.error(errorMessage);
                throw new IllegalPdfFileNameException(errorMessage);
            }

            try {
                // Construct fop with desired output format
                Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, out);

                // Setup XSLT
                TransformerFactory factory = TransformerFactory.newInstance();
                Transformer transformer = factory.newTransformer(new StreamSource(xsltfile));

                if(transformer == null) {
                    String errorMessage = String.format("Failure to read Xsl file, filename: %s", xsltFilename);
                    logger.error(errorMessage);
                    throw new FailureToReadXslFile(errorMessage);
                }

                // Set the value of a <param> in the stylesheet
                transformer.setParameter("versionParam", "2.0");

                // Setup input for XSLT transformation
                Source src = new StreamSource(xmlFile);

                // Resulting SAX events (the generated FO) must be piped through to FOP
                Result res = new SAXResult(fop.getDefaultHandler());

                // Start XSLT transformation and FOP processing
                transformer.transform(src, res);
            } finally {
                out.close();
            }

            logger.debug("Success!");
            logger.debug("Success in generating PDF for specified files");
        } catch (NoXmlDataException e1) {
            throw e1;
        } catch (NoXslTransformationException e2) {
            throw e2;
        } catch (IllegalPdfFileNameException e3) {
            throw e3;
        } catch (FailureToReadXslFile e4) {
            throw e4;
        } catch (FailureToReadXmlFile e5) {
            throw e5;
        } catch (Exception e) {
            logger.error("Unknown exception encountered");
            logger.error(String.format("Message:", e.getMessage()));
            e.printStackTrace(System.err);
            System.exit(-1);
        }
    }

    private void throwExceptionIfXmlFileInvalid(File xmlFile) {
        try {
            DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            documentBuilder.parse(xmlFile);
        } catch (ParserConfigurationException e) {
            String errorMessage = "Failure to validate xml input file";
            logger.error(errorMessage);
            throw new FailureToReadXmlFile(errorMessage);
        } catch (IOException e) {
            String errorMessage = "Failure to validate xml input file";
            logger.error(errorMessage);
            throw new FailureToReadXmlFile(errorMessage);
        } catch (SAXException e) {
            String errorMessage = "Failure to validate xml input file";
            logger.error(errorMessage);
            throw new FailureToReadXmlFile(errorMessage);
        }
    }

    private File createAndReturnTempFopConfigFile() {

        BufferedReader fopConfigFile = null;
        // depending on whether we are running as a standalone jar accessing the xsl file is different
        try {
            InputStream fopConfigIs = FopService.class.getResourceAsStream("/fopConfig.xml");
            fopConfigFile = new BufferedReader(new InputStreamReader(fopConfigIs));
        } catch (NullPointerException e) {
            try {
                File inputFile = new File("src/main/resources/fopConfig.xml");
                fopConfigFile = new BufferedReader(new FileReader(inputFile));
            } catch (FileNotFoundException e1) {
                String errorMessage = String.format("No input fop config file found");
                logger.error(errorMessage);
                throw new NoFopConfigFileException(errorMessage);
            }
        }

        String contentLine = null;
        List<String> configLines = new ArrayList<>();
        String fontDirectoryPlaceholder = "<FONT_DIRECTORY>";
        // String fontDirectory = "C:\\\\dev\\fonts";
        String fontDirectory = this.config.fontsDirectory;
        try {
            contentLine = fopConfigFile.readLine();
            while (contentLine != null) {
                contentLine = contentLine.replace(fontDirectoryPlaceholder, fontDirectory);
                configLines.add(contentLine);
                contentLine = fopConfigFile.readLine();
            }
        } catch (IOException e) {
            String errorMessage = String.format("Failure reading fop config file");
            logger.error(errorMessage);
            throw new NoFopConfigFileException(errorMessage);
        }

        FileWriterService frService = new FileWriterService();
        String newConfigFileFilename = String.format("%s/%s",
                this.config.tempDirectory, "fopConfig.xml");
        frService.writeFile(configLines,newConfigFileFilename);

        return new File(newConfigFileFilename);
    }
}
