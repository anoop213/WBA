package com.dxc.PdfGeneratorMicroservice.models;

public class XslConfigRecord {
    public String labelName;
    public String xslFileName;

    public XslConfigRecord() {
        this.labelName = null;
        this.xslFileName = null;
    }

    public XslConfigRecord(String labelName, String xslFileName) {
        this.labelName = labelName;
        this.xslFileName = xslFileName;
    }
}
