package com.dxc.PdfGeneratorMicroservice.models;

public class ControlFile {
    public Job job;
}
