package com.dxc.PdfGeneratorMicroservice.exceptions;

public class FailureToDetermineLabelSizeException extends RuntimeException {
    public FailureToDetermineLabelSizeException(String errorMessage) {
        super(errorMessage);
    }
}
