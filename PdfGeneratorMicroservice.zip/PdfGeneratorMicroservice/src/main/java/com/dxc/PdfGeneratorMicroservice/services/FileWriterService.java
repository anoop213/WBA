package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.exceptions.NoFileToCopyException;
import com.dxc.PdfGeneratorMicroservice.models.ControlFile;
import com.dxc.PdfGeneratorMicroservice.models.XslConfigFile;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class FileWriterService {
    private Logger logger;

    public FileWriterService() {
        this.logger = LoggerFactory.getLogger(FileWriterService.class);
    }

    public void writeFile(Document dom, String outputFilename) {
        logger.debug("File Writer Service writing file");
        logger.debug(String.format("Output Filename: %s", outputFilename));
        try {
            Transformer tr = TransformerFactory.newInstance().newTransformer();
            tr.setOutputProperty(OutputKeys.INDENT, "yes");
            tr.setOutputProperty(OutputKeys.METHOD, "xml");
            tr.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            //tr.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "roles.dtd");
            tr.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");

            // ensure file created
            File newFile= new File(outputFilename);
            newFile.createNewFile();

            // send DOM to file
            tr.transform(new DOMSource(dom),
                    new StreamResult(new FileOutputStream(outputFilename)));
        } catch(FileNotFoundException e) {
            logger.error("File Not Found Exception encountered");
        } catch (TransformerException e) {
            logger.error("Transformer Exception encountered");
        } catch (IOException e) {
            logger.error("IO Exception encountered");
        }

        logger.debug("Finished writing file");
    }

    public void writeFile(List<String> contents, String outputFilename) {
        logger.debug("File Writer Service writing file");
        logger.debug(String.format("Output Filename: %s", outputFilename));

        StringBuilder sb = new StringBuilder();
        for(String line : contents) {
            sb.append(line);
            sb.append(System.getProperty("line.separator"));
        }

        Path path = Paths.get(outputFilename);
        byte[] strToBytes = sb.toString().getBytes();

        try {
            Files.write(path, strToBytes);
        } catch (IOException e) {
            logger.error("IO Exception encountered");
            return;
        }

        logger.debug("Finished writing file");
    }

    public void writeContentManagerFile(String reportName, String jobName, String formID, String owner, String dosFile, String outputFilename) {
        logger.debug("File Writer Service Writing Content Manager File");

        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-hh.mm.ss");
        String dateTimeStamp = dateFormat.format(date);

        StringBuilder sb = new StringBuilder();
        sb.append("ReportName\tDateTimeStamp\tJobName\tFormID\tOwner\tDosFile");
        sb.append(System.getProperty("line.separator"));

        sb.append(reportName);
        sb.append("\t");
        sb.append(dateTimeStamp);
        sb.append("\t");
        sb.append(jobName);
        sb.append("\t");
        sb.append(formID);
        sb.append("\t");
        sb.append(owner);
        sb.append("\t");
        sb.append(dosFile);
        sb.append(System.getProperty("line.separator"));

        Path path = Paths.get(outputFilename);
        logger.debug(String.format("Content manager file output filepath: %s", outputFilename));
        byte[] strToBytes = sb.toString().getBytes();

        try {
            Files.write(path, strToBytes);
        } catch (IOException e) {
            logger.error("IO Exception encountered");
            return;
        }

        logger.debug("Finished writing content manager file");
    }

    public void writeControlFile(ControlFile controlFile, String outputFilename) {
        logger.debug("File Writer Service Writing Control File");

        try {
            ObjectMapper mapper = new ObjectMapper();

            mapper.writeValue(Paths.get(outputFilename).toFile(), controlFile);

        } catch (Exception ex) {
            logger.error("IO Exception encountered");
            return;
        }

        logger.debug("Finished writing control file");
    }

    public void writeXslConfigFile(XslConfigFile configFile, String outputFilename) {
        logger.debug("File Writer Service Writing Xsl Config File");

        try {
            ObjectMapper mapper = new ObjectMapper();

            mapper.writeValue(Paths.get(outputFilename).toFile(), configFile);

        } catch (Exception ex) {
            logger.error("IO Exception encountered");
            return;
        }

        logger.debug("Finished writing xsl config file");
    }

    public void deleteFile(String filename) {
        logger.debug("File Writer Service Deleting File");

        File file = new File(filename);
        file.delete();

        logger.debug("Finished deleting file");
    }

    public void copyFile(String originalFileName, String resultingFileName) {
        logger.debug("File Writer Service Copying File");

        Path originalPath = Paths.get(originalFileName);
        Path resultingPath = Paths.get(resultingFileName);
        try {
            Files.copy(originalPath, resultingPath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            logger.error("IOException");
            logger.error(e.getMessage());
            String errorMessage =
                    String.format("There is no file to copy at the following path: %s", originalFileName);
            throw new NoFileToCopyException(errorMessage);
        }

        logger.debug("Finished copying file");
    }
}
