package com.dxc.PdfGeneratorMicroservice.exceptions;

public class FailureToReadXmlFile extends RuntimeException {
    public FailureToReadXmlFile(String errorMessage) {
        super(errorMessage);
    }
}
