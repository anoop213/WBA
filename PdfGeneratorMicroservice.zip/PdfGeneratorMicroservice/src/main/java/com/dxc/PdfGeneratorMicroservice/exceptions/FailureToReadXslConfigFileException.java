package com.dxc.PdfGeneratorMicroservice.exceptions;

public class FailureToReadXslConfigFileException extends RuntimeException{
    public FailureToReadXslConfigFileException(String errorMessage) {
        super(errorMessage);
    }
}
