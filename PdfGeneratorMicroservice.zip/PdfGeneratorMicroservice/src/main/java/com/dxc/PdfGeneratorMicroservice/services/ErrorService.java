package com.dxc.PdfGeneratorMicroservice.services;

import java.util.HashMap;
import java.util.Map;

public class ErrorService {
    private static ErrorService instance;
    private Map<String, String> errorMessages;

    private ErrorService() {
        this.errorMessages = new HashMap<>();
    }

    public static synchronized ErrorService getInstance() {
        if(instance == null) {
            instance = new ErrorService();
        }

        return instance;
    }

    public synchronized void putMessage(String cupsUUid, String errorMessage) {
        this.errorMessages.put(cupsUUid, errorMessage);
    }

    public synchronized boolean hasError(String cupsUUid) {
        String errorMessage = this.errorMessages.get(cupsUUid);

        if(errorMessage == null) {
            return false;
        }

        return true;
    }

    public synchronized String getMessage(String cupsUUid) {
        String errorMessage = this.errorMessages.get(cupsUUid);

        if(errorMessage == null) {
            return "Unspecified error message";
        }

        return errorMessage;
    }
}
