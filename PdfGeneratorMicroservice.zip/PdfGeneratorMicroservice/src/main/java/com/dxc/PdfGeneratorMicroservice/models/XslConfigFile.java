package com.dxc.PdfGeneratorMicroservice.models;

public class XslConfigFile {
    public XslConfigRecord[] config;
}
