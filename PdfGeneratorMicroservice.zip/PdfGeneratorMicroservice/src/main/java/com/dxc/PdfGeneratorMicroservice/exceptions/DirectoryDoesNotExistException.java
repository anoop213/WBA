package com.dxc.PdfGeneratorMicroservice.exceptions;

public class DirectoryDoesNotExistException extends RuntimeException {
    public DirectoryDoesNotExistException(String errorMessage) {
        super(errorMessage);
    }
}