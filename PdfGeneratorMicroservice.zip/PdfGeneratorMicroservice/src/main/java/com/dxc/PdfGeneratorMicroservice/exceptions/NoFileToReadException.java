package com.dxc.PdfGeneratorMicroservice.exceptions;

public class NoFileToReadException extends  RuntimeException {
    public NoFileToReadException(String errorMessage) {
        super(errorMessage);
    }
}
