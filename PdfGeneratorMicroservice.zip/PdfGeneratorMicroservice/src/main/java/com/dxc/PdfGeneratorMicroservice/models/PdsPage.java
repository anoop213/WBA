package com.dxc.PdfGeneratorMicroservice.models;

import java.util.ArrayList;
import java.util.List;

public class PdsPage {
    private String formType;
    private List<PdsParam> paramList;

    public PdsPage() {
        this.formType = null;
        this.paramList = new ArrayList<>();
    }

    public String getFormType() {
        return this.formType;
    }

    public void setFormType(String formType) {
        this.formType = formType;
    }

    public void addParam(PdsParam param) {
        this.paramList.add(param);
    }

    public List<PdsParam> getParams() {
        return this.paramList;
    }

    public int getParamsCount() {
        return this.paramList.size();
    }
}