package com.dxc.PdfGeneratorMicroservice.models;

import java.util.HashMap;
import java.util.Map;

public class XslConfig {
    public Map<String, String> xslFileByLabel;

    public XslConfig() {
        this.xslFileByLabel = new HashMap<>();
    }

    public void add(String labelName, String xslFileName) {
        this.xslFileByLabel.put(labelName, xslFileName);
    }

    public String getXslFileForLabel(String labelName) {
        return this.xslFileByLabel.get(labelName);
    }

    public int getCountOfXslFiles() { return this.xslFileByLabel.size(); }
}
