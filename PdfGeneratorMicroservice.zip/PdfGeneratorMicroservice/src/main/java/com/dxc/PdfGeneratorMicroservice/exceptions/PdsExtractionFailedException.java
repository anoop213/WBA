package com.dxc.PdfGeneratorMicroservice.exceptions;

public class PdsExtractionFailedException extends RuntimeException {
    public PdsExtractionFailedException(String errorMessage) {
        super(errorMessage);
    }
}
