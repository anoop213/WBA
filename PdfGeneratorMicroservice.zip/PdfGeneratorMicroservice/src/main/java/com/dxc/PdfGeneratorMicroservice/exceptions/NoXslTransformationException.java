package com.dxc.PdfGeneratorMicroservice.exceptions;

public class NoXslTransformationException extends RuntimeException {
    public NoXslTransformationException(String errorMessage) {
        super(errorMessage);
    }
}
