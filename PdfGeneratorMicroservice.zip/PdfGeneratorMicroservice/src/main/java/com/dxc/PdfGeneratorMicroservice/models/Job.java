package com.dxc.PdfGeneratorMicroservice.models;

public class Job {
    public String cupsUuid;
    public String sdmUuid;
    public String pglFileFilename;
    public String pdfFilepath;
    public String cmInputFileFilepath;
    public String cmOutputFilepath;

    // default constructor for use by object mapper
    public Job() {

    }

    public Job(String cupsUuid, String sdmUuid,
               String pglFileFilename, String pdfFilepath, String cmInputFileFilepath,
               String cmOutputFilepath) {
        this.cupsUuid = cupsUuid;
        this.sdmUuid = sdmUuid;
        this.pglFileFilename = pglFileFilename;
        this.pdfFilepath = pdfFilepath;
        this.cmInputFileFilepath = cmInputFileFilepath;
        this.cmOutputFilepath = cmOutputFilepath;
    }
}
