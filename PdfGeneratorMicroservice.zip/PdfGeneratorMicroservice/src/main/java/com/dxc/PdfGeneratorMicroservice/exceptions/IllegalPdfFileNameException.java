package com.dxc.PdfGeneratorMicroservice.exceptions;

public class IllegalPdfFileNameException extends  RuntimeException {
    public IllegalPdfFileNameException(String errorMessage) {
        super(errorMessage);
    }
}
