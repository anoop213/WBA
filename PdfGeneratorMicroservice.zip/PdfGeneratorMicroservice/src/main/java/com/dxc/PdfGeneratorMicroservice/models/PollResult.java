package com.dxc.PdfGeneratorMicroservice.models;

public enum PollResult {
    Undefined,
    InProgress,
    Failed,
    Completed
}
