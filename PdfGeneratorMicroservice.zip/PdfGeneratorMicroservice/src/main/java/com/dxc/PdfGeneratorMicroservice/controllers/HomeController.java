package com.dxc.PdfGeneratorMicroservice.controllers;

import com.dxc.PdfGeneratorMicroservice.Config;
import com.dxc.PdfGeneratorMicroservice.ControlFileLocker;
import com.dxc.PdfGeneratorMicroservice.exceptions.DirectoryDoesNotExistException;
import com.dxc.PdfGeneratorMicroservice.models.Job;
import com.dxc.PdfGeneratorMicroservice.services.FileReaderService;
import com.dxc.PdfGeneratorMicroservice.services.FileScannerService;
import com.dxc.PdfGeneratorMicroservice.services.PollingService;
import com.dxc.PdfGeneratorMicroservice.threads.AppThread;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/")
public class HomeController {
    private Config config;
    private Logger logger;

    @Autowired
    public HomeController(Config config) {
        this.config = config;
        this.logger = LoggerFactory.getLogger(HomeController.class);
    }

    @GetMapping("/")
    @ResponseBody
    public String home() {
        logger.debug("Home Controller root method called on API");
        return "<p>Home endpoint called</p><p>Please call the activate endpoint to use this appication</p>";
    }

    @GetMapping("/activate")
    @ResponseBody
    public String activate() {
        logger.debug("Home Controller activate method called on API");

        String controlFileSuffix = ".json";
        logger.debug(String.format("Scanning for control files with %s suffix", controlFileSuffix));
        FileScannerService scanner = new FileScannerService(this.config);
        List<File> files = null;
        try {
            files = scanner.scanSharedDirectory(controlFileSuffix);
        } catch(DirectoryDoesNotExistException e)
        {
            logger.error("Control files directory specified in config does not exit");
            logger.error(String.format("The provided value for directories.shared was: %s", config.sharedDirectory));
            logger.error("Processing aborted, you will need to resolve this issue before using this app");
            return "<p>Error: directories.shared config option not correctly set</p>";
        }
        logger.debug(String.format("There are %s control files loaded", files.size()));

        FileReaderService frService = new FileReaderService();
        ControlFileLocker fileLocker = ControlFileLocker.getInstance();
        PollingService pollingService = PollingService.getInstance(this.config, frService);

        if(files.size() == 0) {
            logger.debug("There are no control files present so nothing will be done in this activation");
        }

        for(File file : files) {
            logger.debug(String.format("Processing control file, name: %s", file.getName()));
            String filePath = file.getPath();
            boolean actuallyLockedFile = fileLocker.lockControlFile(filePath);
            logger.debug(String.format("Actually locked file: %s", actuallyLockedFile));
            if(actuallyLockedFile) {
                Job job = frService.readControlFile(filePath);
                logger.debug("Read control file");

                logger.debug("Kicking off new App Thread instance to process control file jobs");
                AppThread thread = new AppThread(job, this.config, filePath, pollingService);
                thread.start();
            }
        }

        logger.debug("The Home Controller Activate method is returning");
        return "<p>Activate</p>";
    }
}
