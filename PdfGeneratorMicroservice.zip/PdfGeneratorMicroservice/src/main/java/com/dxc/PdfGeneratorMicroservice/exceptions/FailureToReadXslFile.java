package com.dxc.PdfGeneratorMicroservice.exceptions;

public class FailureToReadXslFile extends RuntimeException {
    public FailureToReadXslFile(String errorMessage) {
        super(errorMessage);
    }
}
