package com.dxc.PdfGeneratorMicroservice.exceptions;

public class NoXmlDataException extends RuntimeException {
    public NoXmlDataException(String errorMessage) {
        super(errorMessage);
    }
}
