package com.dxc.PdfGeneratorMicroservice.exceptions;

public class NoFileToCopyException extends  RuntimeException {
    public NoFileToCopyException(String errorMessage) {
        super(errorMessage);
    }
}
