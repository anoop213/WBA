package com.dxc.PdfGeneratorMicroservice.exceptions;

public class NoFopConfigFileException extends RuntimeException {
    public NoFopConfigFileException(String errorMessage) {
        super(errorMessage);
    }
}
