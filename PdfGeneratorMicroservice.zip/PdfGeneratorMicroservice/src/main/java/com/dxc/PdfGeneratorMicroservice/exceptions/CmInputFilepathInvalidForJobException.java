package com.dxc.PdfGeneratorMicroservice.exceptions;

public class CmInputFilepathInvalidForJobException extends  RuntimeException {
    public CmInputFilepathInvalidForJobException(String errorMessage) {
        super(errorMessage);
    }
}
