package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.Config;
import com.dxc.PdfGeneratorMicroservice.ControlFileLocker;
import com.dxc.PdfGeneratorMicroservice.exceptions.*;
import com.dxc.PdfGeneratorMicroservice.models.Job;
import com.dxc.PdfGeneratorMicroservice.models.PdsPage;
import com.dxc.PdfGeneratorMicroservice.models.XslConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

import java.io.File;
import java.util.*;

public class AppService {
    private Job job;
    private Config config;
    private String controlFileFilepath;
    private FileReaderService frService;
    private FopService fopService;
    private PdsExtractorService peService;
    private FileWriterService fwService;
    private XmlTransformerService xtService;
    private Logger logger;

    public AppService(Job job, Config config, String controlFileFilepath) {
        this.job = job;
        this.config = config;
        this.controlFileFilepath = controlFileFilepath;

        frService = new FileReaderService();
        fopService = new FopService(config);
        peService = new PdsExtractorService();
        fwService = new FileWriterService();
        xtService = new XmlTransformerService();

        this.logger = LoggerFactory.getLogger(AppService.class);
    }

    public boolean run() {
        System.setProperty("file.encoding", "ISO-8859-1");
        logger.debug("App Service started running");

        boolean ranSuccessfully = false;

        ErrorService errorService = ErrorService.getInstance();
        String cupsUuid = job.cupsUuid;
        try {
            processJob(job);
            ranSuccessfully = true;
        } catch (NoFormTypesInPglException e) {
            logger.error("No form types in input pgl of specified job");
            logger.error(String.format("Input pgl file:", job.pglFileFilename));
            logger.error("Ignoring the job");
            errorService.putMessage(cupsUuid, e.getMessage());
        } catch (PdsExtractionFailedException e) {
            logger.error("No valid Pds could be determined from the pgl file");
            logger.error(String.format("Input pgl file:", job.pglFileFilename));
            logger.error("Ignoring the job");
            errorService.putMessage(cupsUuid, e.getMessage());
        } catch(FailureToDetermineLabelSizeException e) {
            logger.error("Failure to determine label size from the pgl file");
            logger.error(String.format("Input pgl file:", job.pglFileFilename));
            logger.error("Ignoring the job");
            errorService.putMessage(cupsUuid, e.getMessage());
        } catch (RuntimeException e) {
            logger.error("Caught generic Runtime Exception");
            logger.error("Ignoring the job");
            errorService.putMessage(cupsUuid, e.getMessage());
        }

        deleteControlFile();

        unlockControlFile();

        logger.debug("App Service finished running");
        return ranSuccessfully;
    }

    private void processJob(Job job) {
        String pglFilename = null;
        if(config.sharedDirectory.equals("")) {
            // this is to assist unit tests
            pglFilename = job.pglFileFilename;
        } else {
            pglFilename = config.sharedDirectory + "/" + job.pglFileFilename;
        }
        //String xsltFilename = "xsl/transform.xsl";
        String rootPdfFilename = job.pdfFilepath;
        String cmInputFilename = job.cmInputFileFilepath;
        String cmOutputFilename = job.cmOutputFilepath;

        logger.debug("Running App Service for the following files");
        logger.debug(String.format("Pgl filename: %s",pglFilename));
        logger.debug(String.format("Root PDF filename: %s",rootPdfFilename));
        logger.debug(String.format("Content Manger Input Filename: %s",cmInputFilename));
        logger.debug(String.format("Content Manager Output Filename: %s",cmOutputFilename));

        String xsltFilename = getXslFileToUse(pglFilename);

        transformSingleXslTypeFileset(job, pglFilename, rootPdfFilename, cmInputFilename, cmOutputFilename, xsltFilename);
    }

    // Obsolete method from when we thought we produced multiple files when we have more than one form size in the bomb
//    private Map<String, Boolean> getXslFilesToUse(String bombFilename) {
//        logger.debug("Getting xsl files to use");
//
//        XslConfig xslConfig = frService.readXslConfigFile("xslConfig.json");
//        Map<String, Boolean> xslFilesToUse = new HashMap<>();
//        List<String> bombFileLines = frService.readFile(bombFilename);
//        StringBuilder bombFileStringBuilder = new StringBuilder();
//        for(String line : bombFileLines) {
//            bombFileStringBuilder.append(line);
//        }
//        String bombFileString = bombFileStringBuilder.toString().toUpperCase(Locale.ROOT);
//        Set<String> formTypes = xslConfig.xslFileByLabel.keySet();
//        for(String formType : formTypes) {
//            boolean hasForm = bombFileString.contains(formType.toUpperCase(Locale.ROOT));
//            if(hasForm) {
//                xslFilesToUse.put(xslConfig.getXslFileForLabel(formType), true);
//            }
//        }
//
//        logger.debug("Got xsl files to use");
//        return xslFilesToUse;
//    }

    private void unlockControlFile() {
        logger.debug("Unlocking control file");

        ControlFileLocker fileLocker = ControlFileLocker.getInstance();
        fileLocker.unlockControlFile(this.controlFileFilepath);

        logger.debug("Unlocked control file");
    }

//    private void updateOrDeleteControlFile(HashMap<String, Boolean> completedJobs) {
//        logger.debug("Updating or deleting control file");
//
//        ControlFile updatedControlFile = new ControlFile();
//
//        // filter completed jobs
//        List<Job> pendingJobs = getPendingJobs(completedJobs);
//
//        if(pendingJobs.size() == 0) {
//            logger.debug("No pending jobs so deleting control file");
//            fwService.deleteFile(this.controlFileFilepath);
//        } else {
//            logger.debug("Pending control files so updating control file");
//            updatedControlFile.jobs = pendingJobs.toArray(new Job[0]);
//            fwService.writeControlFile(updatedControlFile, this.controlFileFilepath);
//        }
//
//        logger.debug("Updated or deleted control file");
//    }

    public void deleteControlFile() {
        logger.debug("Deleting control file");

        fwService.deleteFile(this.controlFileFilepath);

        logger.debug("Deleted control file");
    }

    // Obsolete method from when we thought we produced multiple files when we have more than one form size in the bomb
//    private void transformMultipleXslTypesFileset(HashMap<String, Boolean> completedJobs, Job job, String bombFilename, String rootPdfFilename, String cmInputFilename, String cmOutputFilename, Map<String, Boolean> xslFilesToUse) {
//        logger.debug("Transforming multiple xsl types fileset");
//
//        boolean failed = false;
//        String xmlFilename = generateXmlFile(bombFilename);
//        int fileNo = 1;
//        Set<String> xslFiles = xslFilesToUse.keySet();
//        for(String xslFile : xslFiles) {
//            String xsltFilename = xslFile;
//            boolean validInputFiles = checkInputFilesExist(bombFilename, xsltFilename, cmInputFilename);
//            logger.debug(String.format("Valid Input Files: %s", validInputFiles));
//            if(validInputFiles) {
//                String pdfFilename = rootPdfFilename.replace(".pdf", fileNo + ".pdf");
//
//                fopService.generatePdfForSpecifiedFiles(xmlFilename, xsltFilename, pdfFilename);
//
//                copyCmFile(cmInputFilename, cmOutputFilename);
//
//                completedJobs.put(job.pdfFilepath, true);
//
//                fileNo++;
//            } else {
//                failed = true;
//            }
//        }
//
//        if(!failed) {
//            logger.debug("Success so deleting input files");
//            deleteInputFiles(bombFilename, cmInputFilename);
//        }
//        deleteXmlFile(xmlFilename);
//
//        logger.debug("Transformed multiple xsl types fileset");
//    }

    private void transformSingleXslTypeFileset(Job job,
                                               String pglFilename, String pdfFilename, String cmInputFilename,
                                               String cmOutputFilename, String xsltFilename) {
        logger.debug("Transforming single xsl type fileset");

        throwExceptionIfInputFilesDoNotExist(pglFilename, xsltFilename, cmInputFilename);

        String xmlFilename = generateXmlFile(pglFilename);

        String tempPdfFileName = null;
        if(config.tempDirectory.equals("")) {
            // this is to assist unit tests
            tempPdfFileName = UUID.randomUUID().toString() + ".pdf";
        } else {
            tempPdfFileName = config.tempDirectory + "/" + UUID.randomUUID().toString() + ".pdf";
        }
        fopService.generatePdfForSpecifiedFiles(xmlFilename, xsltFilename, tempPdfFileName);

        copyTempPdfFileToOutputAndDeleteTempFile(tempPdfFileName, job.pdfFilepath);

        deleteXmlFile(xmlFilename);

        copyCmFile(cmInputFilename, cmOutputFilename);

        deleteInputFiles(pglFilename, cmInputFilename);

        logger.debug("Transformed single xsl type fileset");
    }

//    private List<Job> getPendingJobs(HashMap<String, Boolean> completedJobs) {
//        logger.debug("Getting pending jobs");
//
//        List<Job> pendingJobs = new ArrayList<>();
//        for(Job job : jobs) {
//            if(!completedJobs.containsKey(job.pdfFilepath)) {
//                pendingJobs.add(job);
//            }
//        }
//
//        logger.debug("Got pending jobs");
//        return pendingJobs;
//    }

    private void deleteInputFiles(String pglFilename, String cmInputFilename) {
        logger.debug("Deleting input files");

        fwService.deleteFile(pglFilename);
        fwService.deleteFile(cmInputFilename);

        logger.debug("Deleted input files");
    }

    private String generateXmlFile(String pglFilename) {
        logger.debug("App Thread Generating XML File");
        List<String> lines = frService.readFile( pglFilename);
        logger.debug(String.format("Pgl file has %s lines", lines.size()));
        List<PdsPage> pages = peService.Extract(lines);

        Document xmlDocument = xtService.generateXML(pages);

        UUID xmlUuid = UUID.randomUUID();
        //String xmlFilename = "temp/" + xmlUuid.toString() + ".xml";
        String xmlFilename = null;
        if(config.tempDirectory.equals("")) {
            // this is to assist unit tests
            xmlFilename = xmlUuid.toString() + ".xml";
        } else {
            xmlFilename = config.tempDirectory + "/" + xmlUuid.toString() + ".xml";
        }
        fwService.writeFile(xmlDocument, xmlFilename);

        logger.debug("Finished Generating XML File");
        return xmlFilename;
    }

    private void deleteXmlFile(String xmlFilename) {
        logger.debug("App Thread Deleting XML File");
        fwService.deleteFile(xmlFilename);
        logger.debug("XML file deleted");
    }

    private void copyTempPdfFileToOutputAndDeleteTempFile(String tempPdfFileName, String targetPdfFileName) {
        logger.debug("Copying Temp Pdf File To Output and Deleting Temp File");
        logger.debug(String.format("Temp Pdf FileName: %s", tempPdfFileName));
        logger.debug(String.format("Target Pdf FileName: %s", targetPdfFileName));

        logger.debug("Copying file");
        fwService.copyFile(tempPdfFileName, targetPdfFileName);
        logger.debug("Successfully deleted file");

        logger.debug("Deleting redundant temporary file");
        fwService.deleteFile(tempPdfFileName);
        logger.debug("Successfully deleted redundant temporary file");

        logger.debug("Finished Copying Temp Pdf File To Output and Deleting Temp File");
    }

    private void copyCmFile(String cmInputFilename, String cmOutputFilename) {
        logger.debug("App Thread copying Content Manager File");
        List<String> cmContents = frService.readFile(cmInputFilename);
        fwService.writeFile(cmContents, cmOutputFilename);
        logger.debug("Content Manager File copied");
    }

    private void throwExceptionIfInputFilesDoNotExist(String pglFilename, String xsltFilename, String cmInputFilename) {
        logger.debug("Checking input files exist");
        File pglFile = new File(pglFilename);
        boolean pglFileExists = pglFile.exists();
        logger.debug(String.format("Pgl file exists: %b", pglFileExists));
        if(!pglFileExists) {
            String errorMessage = String.format(
                    "There was no Pgl file to read for the job at the following location: %s", pglFilename);
            throw new PglFilepathInvalidForJobException(errorMessage);
        }

        // File xsltFile = new File(xsltFilename);
        // boolean xsltFileExists = xsltFile.exists();
        //logger.debug(String.format("Xslt file exists: %b", xsltFileExists));

        File cmInputFile = new File(cmInputFilename);
        boolean cmInputFileExists = cmInputFile.exists();
        logger.debug(String.format("Content Manager Input file exists: %b", cmInputFileExists));
        if(!cmInputFileExists) {
            String errorMessage = String.format(
                    "There was no Content Manger Input file to read for the job at the following location: %s",
                    cmInputFilename);
            throw new CmInputFilepathInvalidForJobException(errorMessage);
        }

        logger.debug("Successfully checked that input files exist");
    }

    public String getXslFileToUse(String pglFilename) {
        logger.debug("Getting xsl file to use");

        XslConfig xslConfig = frService.readXslConfigFile("xslConfig.json");
        HashMap<String, Boolean> candidateXslFilesToUse = new HashMap();
        boolean specifiedPglFilepathInvalid = !frService.checkFileExists(pglFilename);
        if(specifiedPglFilepathInvalid) {
            String errorMessage = String.format(
                    "There was no Pgl file to read for the job at the following location: %s", pglFilename);
            throw new PglFilepathInvalidForJobException(errorMessage);
        }
        List<String> pglFileLines = frService.readFile(pglFilename);
        StringBuilder pglFileStringBuilder = new StringBuilder();
        for(String line : pglFileLines) {
            pglFileStringBuilder.append(line);
        }
        String pglFileString = pglFileStringBuilder.toString().toUpperCase(Locale.ROOT);
        Set<String> formTypes = xslConfig.xslFileByLabel.keySet();
        for(String formType : formTypes) {
            boolean hasForm = pglFileString.contains(formType.toUpperCase(Locale.ROOT));
            if(hasForm) {
                candidateXslFilesToUse.put(xslConfig.getXslFileForLabel(formType), true);
            }
        }

        // determine highest size int
        int maximumInches = 0;
        for(String xslFile : candidateXslFilesToUse.keySet()) {
            int inchesOfFile = Integer.parseInt(xslFile.substring(0, 1));
            if(inchesOfFile > maximumInches) {
                maximumInches = inchesOfFile;
            }
        }
        if(maximumInches == 0) {
            String message = String.format("The label size could not be determined, pgl filename: %s", pglFilename);
            throw new FailureToDetermineLabelSizeException(message);
        }
        String chosenXslFile = String.format("%din.xsl", maximumInches);

        logger.debug("Got xsl file to use");
        return chosenXslFile;
    }
}
