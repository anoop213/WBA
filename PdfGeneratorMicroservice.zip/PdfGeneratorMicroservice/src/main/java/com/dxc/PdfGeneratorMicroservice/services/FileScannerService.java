package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.Config;
import com.dxc.PdfGeneratorMicroservice.exceptions.DirectoryDoesNotExistException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class FileScannerService {
    private Config config;
    private String sharedDirectoryFilePath;
    private String tempDirectoryFilePath;
    private Logger logger;

    public FileScannerService(Config config) {
        this.config = config;
        this.sharedDirectoryFilePath = config.sharedDirectory;
        this.tempDirectoryFilePath = config.tempDirectory;
        this.logger = LoggerFactory.getLogger(FileScannerService.class);
        logger.debug("Successfully constructed File Scanner Service instance");
    }

    public List<File> scanSharedDirectory() {
        logger.debug("File Scanner Service Scanning Shared Directory");
        File directory = new File(this.sharedDirectoryFilePath);
        File[] containedFiles = directory.listFiles();

        if(containedFiles == null) {
            throw new DirectoryDoesNotExistException("The directory passed to the file scanner does not exist");
        }

        List<File> results = new ArrayList<File>(Arrays.asList(containedFiles));
        logger.debug("Successfully scanned shared directory");
        return results;
    }

    public List<File> scanSharedDirectory(String fileSuffix) {
        logger.debug(String.format("File Scanner Service Scanning Shared Directory for files with suffix %s", fileSuffix));
        File directory = new File(this.sharedDirectoryFilePath);
        File[] containedFiles = directory.listFiles();

        if(containedFiles == null) {
            throw new DirectoryDoesNotExistException("The directory passed to the file scanner does not exist");
        }

        List<File> matchingFiles = new ArrayList<>();
        for (File file : containedFiles) {
            if(file.getName().toLowerCase(Locale.ROOT).endsWith(fileSuffix.toLowerCase(Locale.ROOT))) {
                matchingFiles.add(file);
            }
        }

        logger.debug("Successfully scanned shared directory");
        return matchingFiles;
    }

    public List<File> scanTempDirectory() {
        logger.debug("File Scanner Service Scanning Temp Directory");
        File directory = new File(this.tempDirectoryFilePath);
        File[] containedFiles = directory.listFiles();

        if(containedFiles == null) {
            throw new DirectoryDoesNotExistException("The directory passed to the file scanner does not exist");
        }

        List<File> results = new ArrayList<File>(Arrays.asList(containedFiles));
        logger.debug("Successfully scanned temp directory");
        return results;
    }

    public List<File> scanTempDirectory(String fileSuffix) {
        logger.debug(String.format("File Scanner Service Scanning Temp Directory for files with suffix %s", fileSuffix));
        File directory = new File(this.tempDirectoryFilePath);
        File[] containedFiles = directory.listFiles();

        if(containedFiles == null) {
            throw new DirectoryDoesNotExistException("The directory passed to the file scanner does not exist");
        }

        List<File> matchingFiles = new ArrayList<>();
        for (File file : containedFiles) {
            if(file.getName().toLowerCase(Locale.ROOT).endsWith(fileSuffix.toLowerCase(Locale.ROOT))) {
                matchingFiles.add(file);
            }
        }

        logger.debug("Successfully scanned temp directory");
        return matchingFiles;
    }
}
