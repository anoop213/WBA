package com.dxc.PdfGeneratorMicroservice;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
//@PropertySource("classpath:/application.properties")
public class Config {
    @Value( "${directories.shared}" )
    public String sharedDirectory;
    @Value( "${directories.temp}" )
    public String tempDirectory;
    @Value( "${directories.fonts}" )
    public String fontsDirectory;
}
