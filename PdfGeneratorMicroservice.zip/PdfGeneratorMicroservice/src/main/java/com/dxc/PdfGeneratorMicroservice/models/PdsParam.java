package com.dxc.PdfGeneratorMicroservice.models;

public class PdsParam {
    private String name;
    private String value;

    public PdsParam(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return this.name;
    }

    public String getValue() {
        return this.value;
    }
}