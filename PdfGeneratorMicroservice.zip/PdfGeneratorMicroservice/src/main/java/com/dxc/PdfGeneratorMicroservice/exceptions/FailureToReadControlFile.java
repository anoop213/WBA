package com.dxc.PdfGeneratorMicroservice.exceptions;

public class FailureToReadControlFile extends RuntimeException {
    public FailureToReadControlFile(String errorMessage) {
        super(errorMessage);
    }
}
