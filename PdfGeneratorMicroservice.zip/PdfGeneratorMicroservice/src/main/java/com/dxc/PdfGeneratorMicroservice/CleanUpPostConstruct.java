package com.dxc.PdfGeneratorMicroservice;

import com.dxc.PdfGeneratorMicroservice.services.TempFilesCleanupService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class CleanUpPostConstruct {
    private Config config;
    private Logger logger;

    public CleanUpPostConstruct(Config config) {
        this.config = config;
        this.logger = LoggerFactory.getLogger(CleanUpPostConstruct.class);
    }

    @PostConstruct
    public void postConstruct(){
        logger.debug("Clean Up Post Construct Running");
        logger.debug(String.format("Temp dir: %s", config.tempDirectory));

        logger.debug("Instantiating instance of Temp Files Cleanup Service");
        TempFilesCleanupService service = new TempFilesCleanupService(this.config);
        logger.debug("Successfully instantiated Temp Files Cleanup Service");

        logger.debug("Running Temp Files Cleanup Service Clean Old Pdfs");
        service.cleanOldPdfs();
        logger.debug("Finished Running Temp Files Cleanup Service Clean Old Pdfs");

        logger.debug("Finished Clean Up Post Construct");
    }
}
