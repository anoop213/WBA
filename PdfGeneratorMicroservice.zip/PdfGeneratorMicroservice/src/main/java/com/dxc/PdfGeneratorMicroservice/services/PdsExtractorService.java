package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.exceptions.PdsExtractionFailedException;
import com.dxc.PdfGeneratorMicroservice.models.PdsPage;
import com.dxc.PdfGeneratorMicroservice.models.PdsParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class PdsExtractorService {
    private Logger logger;

    public PdsExtractorService() {
        this.logger = LoggerFactory.getLogger(PdsExtractorService.class);
        logger.debug("Successfully instantiated Pds Extractor Service");
    }

    public List<PdsPage> Extract(List<String> lines) {
        logger.debug("Pds Extractor Service Extracting");
        ArrayList<PdsPage> result = new ArrayList<PdsPage>();

        PdsPage currentPdsPage = null;
        for(String line : lines) {
            if(isExecuteLine(line)) {
                if(currentPdsPage != null) {
                    result.add(currentPdsPage);
                }

                String formType = getFormTypeFromExecuteLine(line);
                currentPdsPage = new PdsPage();
                currentPdsPage.setFormType(formType);
            } else if(isParamLine(line)) {
                PdsParam pdsParam = getPdsParamFromParamLine(line);
                currentPdsPage.addParam(pdsParam);
            }
        }
        if(currentPdsPage != null) {
            result.add(currentPdsPage);
        }

        if(result.size() == 0) {
            throw new PdsExtractionFailedException("No pds pages could be derived from the input lines");
        }

        logger.debug("Extraction successfully finished");
        return result;
    }

    private boolean isExecuteLine(String line) {
        return line.startsWith("¬EXECUTE");
    }

    private boolean isParamLine(String line) {
        return line.contains("¦");
    }

    private String getFormTypeFromExecuteLine(String line) {
        String[] parts = line.split(";");
        return parts[1];
    }

    private PdsParam getPdsParamFromParamLine(String line) {
        String[] parts = line.split("¦");

        String name = parts[0].substring(1, parts[0].length() - 1);
        String value = parts[1];

        return new PdsParam(name, value);
    }
}