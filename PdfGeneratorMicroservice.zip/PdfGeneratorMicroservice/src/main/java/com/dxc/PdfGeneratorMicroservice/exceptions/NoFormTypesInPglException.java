package com.dxc.PdfGeneratorMicroservice.exceptions;

public class NoFormTypesInPglException extends RuntimeException {
    public NoFormTypesInPglException(String errorMessage) {
        super(errorMessage);
    }
}