package com.dxc.PdfGeneratorMicroservice.threads;

import com.dxc.PdfGeneratorMicroservice.Config;
import com.dxc.PdfGeneratorMicroservice.models.Job;
import com.dxc.PdfGeneratorMicroservice.services.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppThread extends Thread {
    private Job job;
    private Config config;
    private String controlFileFilepath;
    private PollingService pollingService;
    private Logger logger;

    public AppThread(Job job, Config config, String controlFileFilepath, PollingService pollingService) {
        this.job = job;
        this.config = config;
        this.controlFileFilepath = controlFileFilepath;
        this.pollingService = pollingService;
        this.logger = LoggerFactory.getLogger(AppThread.class);
        logger.debug("Successfully instantiated App Thread instance");
    }

    public void run() {
        logger.debug("App Thread Running");

        AppService service = new AppService(job, this.config, this.controlFileFilepath);

        try {
            logger.debug("App thread running app service");
            boolean ranSuccessfully = service.run();
            logger.debug("App Thread finished running app service");

            if(ranSuccessfully) {
                logger.debug("App thread ran successfully setting job as completed for polling service");
                pollingService.setComplete(this.job.cupsUuid);
                logger.debug("App thread finished setting jobs as completed for polling service");
            } else {
                logger.debug("App thread finished running failed job which was not marked as completed");
            }

        } catch(Exception e) {
            logger.error("Exception encountered");
            logger.error(String.format("Message: %s", e.getMessage()));
        }

        logger.debug("App thread finished running");
    }
}