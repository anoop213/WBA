package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.models.PdsPage;
import com.dxc.PdfGeneratorMicroservice.models.PdsParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.util.List;

public class XmlTransformerService {
    private Logger logger;

    public XmlTransformerService() {
        this.logger = LoggerFactory.getLogger(XmlTransformerService.class);
    }

    public Document generateXML(List<PdsPage> pages) {
        logger.debug("Xml Transformer Service generating XML");
        Document dom = null;

        // instance of a DocumentBuilderFactory
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        //dbf.setNamespaceAware(true);
        try {
            // use factory to get an instance of document builder
            DocumentBuilder db = dbf.newDocumentBuilder();
            // create instance of DOM
            dom = db.newDocument();

            // create the root element
            Element rootEle = dom.createElement("labeldata");
            //rootEle.setAttributeNS(XMLConstants.XML_NS_URI, "xml:space", "preserve");

            // create data elements and place them under root
            for(PdsPage page : pages) {
                Element pageElement = dom.createElement("page");
                Element formElement = dom.createElement(page.getFormType());
                //Element pageElement = dom.createElement(page.getFormType());
                for(PdsParam param: page.getParams()) {
                    Element e = null;
                    e = dom.createElement(param.getName());
                    e.appendChild(dom.createTextNode(param.getValue()));
                    //e.setAttribute("xml:space", "preserve");
                    formElement.appendChild(e);
                }
                pageElement.appendChild(formElement);
                rootEle.appendChild(pageElement);
            }

            dom.appendChild(rootEle);
            logger.debug("Successfully generated xml");
        } catch (ParserConfigurationException pce) {
            logger.error("Parser Configuration Exception encountered");
            logger.error(String.format("Message:", pce.getMessage()));
        }

        return dom;
    }
}