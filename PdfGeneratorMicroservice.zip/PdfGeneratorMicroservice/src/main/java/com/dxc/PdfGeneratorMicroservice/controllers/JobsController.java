package com.dxc.PdfGeneratorMicroservice.controllers;

import com.dxc.PdfGeneratorMicroservice.Config;
import com.dxc.PdfGeneratorMicroservice.ControlFileLocker;
import com.dxc.PdfGeneratorMicroservice.models.Job;
import com.dxc.PdfGeneratorMicroservice.models.PollResult;
import com.dxc.PdfGeneratorMicroservice.models.WrappedPollResult;
import com.dxc.PdfGeneratorMicroservice.services.ErrorService;
import com.dxc.PdfGeneratorMicroservice.services.FileReaderService;
import com.dxc.PdfGeneratorMicroservice.services.PollingService;
import com.dxc.PdfGeneratorMicroservice.threads.AppThread;
import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/jobs")
public class JobsController {
    private Config config;
    private Logger logger;

    @Autowired
    public JobsController(Config config) {
        this.config = config;
        this.logger = LoggerFactory.getLogger(HomeController.class);
    }
    
    @PutMapping("/{cupsUuid}")
    @ResponseBody
    public String activate(@PathVariable String cupsUuid) {
        logger.debug("Jobs Controller activate (Put) method called on API");
        logger.debug(String.format("Provided Cups Uuid: %s", cupsUuid));

        FileReaderService frService = new FileReaderService();

        String controlFileName = String.format("%s/%s.json", config.sharedDirectory, cupsUuid);
        logger.debug(String.format("Using control file name: %s", controlFileName));

        boolean controlFileExists = frService.checkFileExists(controlFileName);
        logger.debug("Control file exists: %s", controlFileExists);

        ControlFileLocker fileLocker = ControlFileLocker.getInstance();
        logger.debug("Attempting to lock control file");
        boolean actuallyLockedFile = fileLocker.lockControlFile(controlFileName);
        logger.debug("Locked control file: %s", actuallyLockedFile);

        if(controlFileExists && actuallyLockedFile) {
            logger.debug("Control file exists so running job");
            logger.debug("Reading control file");
            Job job = frService.readControlFile(controlFileName);
            logger.debug("Successfully read control file");

            logger.debug("Instantiating polling service");
            PollingService pollingService = PollingService.getInstance(this.config, frService);
            logger.debug("Successfully instantiated polling service");

            logger.debug("Instantiating app thread");
            AppThread thread = new AppThread(job, this.config, controlFileName, pollingService);
            logger.debug("Successfully instantiated app thread");

            logger.debug("Running app thread");
            thread.run();
            logger.debug("Ran app thread");
        } else {
            logger.debug("Unable to process control file");
            logger.debug("Control file exists: %s", controlFileExists);
            logger.debug("Locked control file: %s", actuallyLockedFile);
            logger.debug("Ignoring file");

            return "<p>Failed to activate</p>";
        }
//
//            logger.debug("Instantiating app service");
//            AppService appService = new AppService(job, this.config, controlFileName);
//            logger.debug("Successfully instantiated app service");
//
//            logger.debug("Running app service for job");
//            boolean successfullyRan = appService.run();
//            logger.debug("Finished running app service for job");
//            logger.debug("Job ran successfully: %s", successfullyRan);
//
//            if(successfullyRan) {
//                logger.debug("Successfully ran app service for job");
//
//                logger.debug("Using polling service to set job as completed");
//                PollingService pollingService = PollingService.getInstance(this.config, frService);
//                pollingService.setComplete(cupsUuid);
//                logger.debug("Successfully used polling service to set job as completed ");
//
//                logger.debug("Successfully activated for specified control file");
//                logger.debug(String.format("Provided Cups Uuid: %s", cupsUuid));
//                return "<p>Successful Activation</p>";
//            }

        return "<p>Successful Activation";
    }

    @GetMapping("/{cupsUuid}/poll")
    @ResponseBody
    public String poll(@PathVariable String cupsUuid) {
        logger.debug("Jobs Controller poll (Get) method called on API");
        logger.debug(String.format("Provided Cups Uuid: %s", cupsUuid));

        Gson gson = new Gson();

        FileReaderService frService = new FileReaderService();
        PollingService pollingService = PollingService.getInstance(this.config, frService);

        logger.debug("Using poll service to poll the job");
        PollResult result = pollingService.poll(cupsUuid);
        logger.debug("Successfully polled the job using poll service");

//        String statusMessage = "";
//        switch(result) {
//            case Completed:
//                statusMessage = "Completed";
//                break;
//            case InProgress:
//                statusMessage = "InProgress";
//                break;
//            case Undefined:
//                statusMessage = "Undefined";
//                break;
//            default:
//                statusMessage = "Error polling the job";
//                break;

        if(result.equals(PollResult.Failed)) {
            ErrorService errorService = ErrorService.getInstance();
            String errorMessage = errorService.getMessage(cupsUuid);
            logger.debug("Returning failed poll result to the client: %s");
            logger.debug(String.format("Returning the following error message to the client: %s", errorMessage));

            WrappedPollResult wrappedResult = new WrappedPollResult(result, errorMessage);

            return gson.toJson(wrappedResult);
        }

        logger.debug(String.format("Returning the following poll result to the client: %s", result));
        WrappedPollResult wrappedResult = new WrappedPollResult(result);
        return gson.toJson(wrappedResult);
    }
}
