package com.dxc.PdfGeneratorMicroservice.services;

import com.dxc.PdfGeneratorMicroservice.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.List;

public class TempFilesCleanupService {
    private FileScannerService fsService;
    private FileWriterService fwService;
    private Logger logger;

    public TempFilesCleanupService(Config config) {
        this.fsService = new FileScannerService(config);
        this.fwService = new FileWriterService();
        this.logger = LoggerFactory.getLogger(TempFilesCleanupService.class);
    }

    public void cleanOldPdfs() {
        logger.debug("Temp Files Cleanup Service Cleaning Old Pdfs");

        List<File> filesToRemove = fsService.scanTempDirectory(".pdf");

        for(File fileToRemove : filesToRemove) {
            String fileToRemovePath = fileToRemove.getAbsolutePath();
            logger.debug(String.format("Removing file, file path: %s", filesToRemove));
            fwService.deleteFile(fileToRemovePath);
            logger.debug("Successfully removed file");
        }

        logger.debug("Temp Files Cleanup Service Finished Cleaning Old Pdfs");
    }
}
