package com.dxc.PdfGeneratorMicroservice.models;

public class WrappedPollResult {
    private PollResult pollResult;
    private String errorMessage;

    public WrappedPollResult(PollResult pollResult) {
        this.pollResult = pollResult;
        this.errorMessage = "No error";
    }

    public WrappedPollResult(PollResult pollResult, String errorMessage) {
        this.pollResult = pollResult;
        this.errorMessage = errorMessage;
    }
}
